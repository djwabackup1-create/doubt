"""Run a localhost nginx/PHP-FPM store and a connection-owned Tor onion service."""
import argparse
from contextlib import closing
import getpass
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
HEALTH_INTERVAL = 15
MONITOR_INTERVAL = 1


class RecoverableError(RuntimeError):
    pass


class RestartBudget:
    def __init__(self, clock=time.monotonic):
        self.clock=clock
        self.failures=[]

    def next_delay(self):
        now=self.clock()
        self.failures=[value for value in self.failures if now-value<600]
        if len(self.failures)>=5:
            raise RuntimeError('Recovery limit reached: five restarts in ten minutes. Hosting stopped; inspect the cause before restarting.')
        self.failures.append(now)
        return min(30,2**len(self.failures))


def process_token(pid):
    try:return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
    except (OSError,IndexError):return None


def read_status(storage):
    try:
        value=json.loads((storage/'hosting-status.json').read_text())
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError):return {}


def status_alive(value):
    try:
        pid=int(value['pid'])
        return pid>1 and Path(f'/proc/{pid}').stat().st_uid==os.getuid() and bool(value.get('token')) and process_token(pid)==value['token'] and b'host_onion.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
    except (OSError,ValueError,KeyError,TypeError):return False


def write_status(storage,state,**changes):
    value=read_status(storage)
    value.update(pid=os.getpid(),token=process_token(os.getpid()),state=state,updated_at=time.time())
    value.update(changes)
    fd,name=tempfile.mkstemp(prefix='.hosting-status-',dir=storage)
    try:
        with os.fdopen(fd,'w') as output:
            json.dump(value,output);output.flush();os.fsync(output.fileno())
        os.replace(name,storage/'hosting-status.json')
    finally:
        Path(name).unlink(missing_ok=True)


def manage(storage,stop=False):
    value=read_status(storage)
    if not status_alive(value):
        print('BitCart is stopped. '+value.get('url',''));return
    if not stop:
        print('BitCart: '+value.get('state','running')+' '+value.get('url',''));return
    os.kill(int(value['pid']),signal.SIGTERM)
    deadline=time.monotonic()+40
    while status_alive(value) and time.monotonic()<deadline:time.sleep(.2)
    if status_alive(value):raise RuntimeError('The launcher is still stopping. Inspect it before restarting; no process was forcibly killed.')
    print('BitCart stopped. Store data and onion keys were retained.')


def check_persistent_state(storage,backup=False):
    key=storage/'onion/private_key';hostname=storage/'onion/hostname'
    if key.is_symlink() or hostname.is_symlink():raise RuntimeError('Onion identity files must not be symlinks')
    if hostname.exists() and not key.exists():raise RuntimeError('Saved onion key is missing. Restore it from backup; the address will not be replaced.')
    if key.exists():
        import base64
        try:
            value=key.read_text().strip()
            valid=value.startswith('ED25519-V3:') and len(base64.b64decode(value.split(':',1)[1],validate=True))==64
        except (OSError,ValueError):valid=False
        if not valid:raise RuntimeError('Saved onion key is damaged. Restore it from backup; automatic key replacement is disabled.')
    database=storage/'store.sqlite'
    if not database.exists():return
    try:
        with closing(sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True,timeout=5)) as connection:
            if connection.execute('PRAGMA quick_check').fetchall()!=[('ok',)]:raise RuntimeError('Database integrity check failed. Hosting stopped; the original database was not changed.')
            if backup:
                directory=storage/'backups';directory.mkdir(mode=0o700,exist_ok=True);directory.chmod(0o700)
                target=directory/f'pre-start-{time.time_ns()}.sqlite'
                with closing(sqlite3.connect(target)) as destination:connection.backup(destination)
                target.chmod(0o600)
                for stale in sorted(directory.glob('pre-start-*.sqlite'),reverse=True)[3:]:stale.unlink()
    except sqlite3.Error as error:
        raise RuntimeError('Cannot validate/back up the database. Hosting stopped without resetting store data.') from error


def healthy_http(port):
    client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with client.open(f'http://127.0.0.1:{port}/',timeout=3) as response:
            return response.status==200 and b'BITCART_PRODUCTS' in response.read(2*1024*1024)
    except (OSError,urllib.error.URLError):return False


def stop_owned_group(process):
    """Stop owned worker groups even if their master has already crashed."""
    current=process_token(process.pid)
    original=getattr(process,'_bitcart_start_token',None)
    if current is not None and original is not None and current!=original:
        raise RuntimeError('A managed PID was reused. Refusing to signal an unrelated process group.')
    try:os.killpg(process.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait(timeout=5)
    # A dead master can leave live nginx/FPM workers holding listening sockets.
    # SIGTERM reaches them too; allow a brief drain before the next attempt.
    deadline=time.monotonic()+2
    while time.monotonic()<deadline:
        try:os.killpg(process.pid,0)
        except ProcessLookupError:return
        time.sleep(.1)
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass


def quoted(value):
    value = str(value)
    if any(char in value for char in '\r\n\0'):
        raise RuntimeError('Paths cannot contain newlines or NUL characters')
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$') + '"'


def ini_quoted(value):
    # Dollar expansion is supported by PHP's INI parser: exclude it in paths.
    if '$' in str(value):
        raise RuntimeError('The hosting paths must not contain dollar signs')
    return quoted(value)


def nginx_config(root, runtime, port):
    return f'''pid {quoted(runtime/'nginx.pid')};
error_log {quoted(runtime/'nginx-error.log')} warn;
worker_processes 2;
daemon off;
events {{ worker_connections 256; }}
http {{
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    access_log off;
    server_tokens off;
    client_max_body_size 12m;
    client_body_timeout 30s;
    send_timeout 30s;
    client_body_temp_path {quoted(runtime/'client-body')};
    fastcgi_temp_path {quoted(runtime/'fastcgi-temp')};
    proxy_temp_path {quoted(runtime/'proxy-temp')};
    scgi_temp_path {quoted(runtime/'scgi-temp')};
    uwsgi_temp_path {quoted(runtime/'uwsgi-temp')};
    server {{
        listen 127.0.0.1:{port};
        server_name _;
        root {quoted(root/'public')};
        index index.php;
        add_header X-Content-Type-Options nosniff always;
        add_header Referrer-Policy no-referrer always;
        add_header X-Frame-Options DENY always;
        location = /setup.php {{ return 404; }}
        location ~ /\\. {{ deny all; }}
        location / {{ try_files $uri $uri/ =404; }}
        location ~ \\.php$ {{
            try_files $uri =404;
            fastcgi_pass unix:{runtime/'php.sock'};
            fastcgi_hide_header X-Powered-By;
            fastcgi_read_timeout 40s;
            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
            fastcgi_param SCRIPT_NAME $fastcgi_script_name;
            fastcgi_param QUERY_STRING $query_string;
            fastcgi_param REQUEST_METHOD $request_method;
            fastcgi_param CONTENT_TYPE $content_type;
            fastcgi_param CONTENT_LENGTH $content_length;
            fastcgi_param REQUEST_URI $request_uri;
            fastcgi_param DOCUMENT_URI $document_uri;
            fastcgi_param DOCUMENT_ROOT $document_root;
            fastcgi_param SERVER_PROTOCOL $server_protocol;
            fastcgi_param REQUEST_SCHEME $scheme;
            fastcgi_param GATEWAY_INTERFACE CGI/1.1;
            fastcgi_param SERVER_SOFTWARE nginx;
            fastcgi_param REMOTE_ADDR $remote_addr;
            fastcgi_param REMOTE_PORT $remote_port;
            fastcgi_param SERVER_ADDR $server_addr;
            fastcgi_param SERVER_PORT $server_port;
            fastcgi_param SERVER_NAME $server_name;
            fastcgi_param REDIRECT_STATUS 200;
        }}
    }}
}}
'''


def fpm_config(storage, runtime, user, group):
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', user) or not re.fullmatch(r'[a-zA-Z0-9_-]+', group):
        raise RuntimeError('Unsupported Linux user or group name')
    return f'''[global]
pid = {ini_quoted(runtime/'php-fpm.pid')}
error_log = {ini_quoted(runtime/'php-fpm.log')}
daemonize = no
[bitcart]
user = {user}
group = {group}
listen = {ini_quoted(runtime/'php.sock')}
listen.mode = 0600
pm = ondemand
pm.max_children = 8
pm.process_idle_timeout = 10s
request_terminate_timeout = 40s
clear_env = yes
env[BITCART_STORAGE_DIR] = {ini_quoted(storage)}
php_admin_flag[display_errors] = off
php_admin_flag[log_errors] = on
php_admin_flag[expose_php] = off
php_admin_value[error_log] = {ini_quoted(runtime/'php-errors.log')}
php_admin_value[upload_max_filesize] = 10M
php_admin_value[post_max_size] = 12M
php_admin_value[upload_tmp_dir] = {ini_quoted(runtime/'uploads')}
php_admin_value[session.save_path] = {ini_quoted(runtime/'sessions')}
php_admin_value[session.use_strict_mode] = 1
php_admin_value[max_execution_time] = 30
php_admin_value[memory_limit] = 128M
php_admin_value[cgi.fix_pathinfo] = 0
security.limit_extensions = .php
'''


def is_tails():
    return Path('/etc/amnesia/version').exists() or bool(re.search(r'^ID=["\']?tails["\']?$', Path('/etc/os-release').read_text(), re.M))


def storage_location(root, override, tails, home):
    storage = Path(override).expanduser().resolve() if override else (root/'storage').resolve()
    if storage == (root/'public').resolve() or (root/'public').resolve() in storage.parents:
        raise RuntimeError('Private storage must be outside public/')
    if tails:
        persistent = home/'Persistent'
        if not persistent.is_dir():
            raise RuntimeError('Unlock Tails Persistent Storage before starting the store')
        persistent = persistent.resolve()
        if persistent not in root.resolve().parents or not (storage == persistent or persistent in storage.parents):
            raise RuntimeError('On Tails, put the project folder and private storage inside ~/Persistent before running this launcher')
    return storage


def find_tools():
    missing=[name for name in ('php','nginx','tor') if shutil.which(name) is None]
    if missing:raise RuntimeError('Missing requirements: '+', '.join(missing)+'. Run sh host-onion.sh to install them.')
    php=shutil.which('php')
    version=subprocess.check_output([php,'-r','echo PHP_MAJOR_VERSION,".",PHP_MINOR_VERSION;'],text=True).strip()
    fpm=Path('/usr/sbin/php-fpm'+version)
    if not fpm.is_file():raise RuntimeError('Install PHP-FPM matching PHP '+version+'. Run sh host-onion.sh.')
    result=subprocess.run([php,'-r','exit(PHP_VERSION_ID>=80100 && extension_loaded("pdo_sqlite") && extension_loaded("mbstring") && extension_loaded("session") && function_exists("getimagesize") ? 0 : 1);'])
    if result.returncode:raise RuntimeError('PHP 8.1+, PDO SQLite, mbstring, session and image support are required.')
    return php,str(fpm),shutil.which('nginx'),shutil.which('tor')


def ensure_admin(php, storage):
    config = storage/'config.php'
    if config.exists():
        valid = subprocess.run([php, '-r', '$c=require $argv[1];exit(is_array($c)&&!empty($c["password_hash"])&&password_get_info($c["password_hash"])["algo"]!==null?0:1);', str(config)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if valid.returncode:
            raise RuntimeError('The saved admin configuration is invalid; fix it before publishing')
        return
    if not sys.stdin.isatty():
        raise RuntimeError('Create the first admin password in an interactive terminal before publishing')
    print('Create the admin password before the site becomes public. It will not be displayed.')
    while True:
        password = getpass.getpass('New admin password (at least 12 characters): ')
        confirmation = getpass.getpass('Confirm password: ')
        if len(password) >= 12 and password == confirmation:
            break
        print('Passwords must match and contain at least 12 characters.')
    hashed = subprocess.check_output([php, '-r', 'echo var_export(password_hash(stream_get_contents(STDIN),PASSWORD_DEFAULT),true);'], input=password, text=True)
    # Exclusive creation avoids overwriting an admin configured by another process.
    fd = os.open(config, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as output:
        output.write("<?php\nreturn ['password_hash' => " + hashed + "];\n")


def wait_http(port, processes, timeout=20):
    client = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        if any(process.poll() is not None for process in processes):
            raise RuntimeError('The local server exited during startup; check the private runtime logs printed above')
        try:
            with client.open(f'http://127.0.0.1:{port}/', timeout=2) as response:
                if response.status == 200:
                    return
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(.2)
    raise RuntimeError('The local storefront did not become ready')


def desktop_argument(value):
    value=str(value)
    if any(char in value for char in '\r\n%'):raise RuntimeError('Unsupported characters in desktop launcher path')
    return '"'+value.replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$')+'"'


def create_desktop_launcher(root, storage=None, port=8080, home=None):
    home=home or Path.home()
    storage=storage or root/'storage'
    desktop=home/'Desktop'
    if shutil.which('xdg-user-dir'):
        result=subprocess.run(['xdg-user-dir','DESKTOP'],capture_output=True,text=True)
        candidate=Path(result.stdout.strip())
        if result.returncode==0 and candidate.is_absolute() and candidate!=home:desktop=candidate
    menu=home/'.local/share/applications'
    targets=[root,desktop,menu]
    prefix='/usr/bin/env '+desktop_argument('BITCART_STORAGE_DIR='+str(storage))+' '+desktop_argument('BITCART_PORT='+str(port))+' /bin/sh '+desktop_argument(root/'host-onion.sh')
    for directory in targets:
        directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        for filename,name,option in [('Start BitCart.desktop','Start BitCart Onion Store',''),('Stop BitCart.desktop','Stop BitCart Onion Store',' --stop')]:
            target=directory/filename
            if target.is_symlink():raise RuntimeError('Desktop launcher target must not be a symlink')
            target.write_text('[Desktop Entry]\nType=Application\nName='+name+'\nComment=Manage the BitCart onion store\nTerminal=true\nExec='+prefix+option+'\nIcon=network-server\nCategories=Network;\n',encoding='utf-8')
            target.chmod(0o700)
            if shutil.which('gio'):subprocess.run(['gio','set',str(target),'metadata::trusted','true'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    print('Start/Stop shortcuts created on your Desktop and in the application menu.',flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    management=parser.add_mutually_exclusive_group()
    management.add_argument('--status',action='store_true')
    management.add_argument('--stop',action='store_true')
    management.add_argument('--restart',action='store_true')
    parser.add_argument('--check', action='store_true', help='Read-only prerequisite check; do not install or publish')
    args = parser.parse_args()
    if sys.platform != 'linux' or os.geteuid() == 0:
        raise RuntimeError('Run sh host-onion.sh as a normal user on Tails, Debian or Ubuntu')
    import fcntl
    import grp
    import pwd
    os.umask(0o077)
    tails = is_tails()
    storage = storage_location(ROOT, os.environ.get('BITCART_STORAGE_DIR'), tails, Path.home())
    if args.status or args.stop:
        manage(storage,stop=args.stop);return
    php, fpm, nginx, tor = find_tools()
    if args.restart:manage(storage,stop=True)
    current=read_status(storage)
    if not args.check and status_alive(current):
        print('This store is already running. '+current.get('url',''));return
    port = int(os.environ.get('BITCART_PORT', '8080'))
    if not 1024 <= port <= 65535:
        raise RuntimeError('BITCART_PORT must be between 1024 and 65535')
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(('127.0.0.1', port))
    if args.check:
        print('Prerequisites available. Mode: ' + ('Tails existing Tor' if tails else 'isolated Tor process'))
        print('Private storage: ' + str(storage))
        print(f'Local binding: 127.0.0.1:{port}; external onion port: 80')
        print('No onion service was created by --check.')
        return
    storage.mkdir(parents=True, mode=0o700, exist_ok=True)
    storage.chmod(0o700)
    lock_fd = os.open(storage/'hosting.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(lock_fd, 'w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('This store is already being hosted by another launcher') from None
        check_persistent_state(storage,backup=True)
        ensure_admin(php, storage)
        # Initialize/migrate storage before starting the network-facing workers.
        subprocess.run([php, '-r', 'require $argv[1];', str(ROOT/'src/bootstrap.php')], env=dict(os.environ, BITCART_STORAGE_DIR=str(storage)), check=True)
        if tails:
            print('Authorizing access to Tails’ existing Tor control socket. Tor and firewall configuration will not be changed.', flush=True)
            subprocess.run(['sudo', '-v'], check=True)
        create_desktop_launcher(ROOT,storage,port)
        with tempfile.TemporaryDirectory(prefix='bitcart-', dir='/tmp') as temporary:
            runtime = Path(temporary)
            print('Private runtime logs (exist while running): '+str(runtime), flush=True)
            for name in ('uploads','sessions','client-body','fastcgi-temp','proxy-temp','scgi-temp','uwsgi-temp'):
                (runtime/name).mkdir(mode=0o700)
            nginx_path = runtime/'nginx.conf'
            fpm_path = runtime/'php-fpm.conf'
            nginx_path.write_text(nginx_config(ROOT, runtime, port))
            fpm_path.write_text(fpm_config(storage, runtime, pwd.getpwuid(os.getuid()).pw_name, grp.getgrgid(os.getgid()).gr_name))
            subprocess.run([fpm, '-t', '-y', str(fpm_path)], check=True)
            subprocess.run([nginx, '-t', '-p', str(runtime)+'/', '-c', str(nginx_path)], check=True)
            def serve_attempt():
                processes = []
                controller = None
                with (runtime/'processes.log').open('w') as log:
                    try:
                        def launch(command, **kwargs):
                            process = subprocess.Popen(command, stdout=log, stderr=log, start_new_session=True, **kwargs)
                            process._bitcart_start_token=process_token(process.pid)
                            processes.append(process)
                            return process
                        launch([fpm, '-F', '-y', str(fpm_path)])
                        launch([nginx, '-p', str(runtime)+'/', '-c', str(nginx_path)])
                        try:wait_http(port, processes)
                        except RuntimeError as error:raise RecoverableError(str(error)) from error
                        print('Local storefront ready. Creating the onion service…', flush=True)
                        control_command = [sys.executable, str(ROOT/'scripts/tor_service.py'), '--storage', str(storage), '--port', str(port)]
                        if tails:
                            control_command = ['sudo', '-n'] + control_command
                        else:
                            tor_state = storage/'tor-state'
                            tor_state.mkdir(mode=0o700, exist_ok=True)
                            tor_path = runtime/'torrc'
                            tor_path.write_text(f'DataDirectory {quoted(tor_state)}\nSocksPort 0\nControlSocket {quoted(runtime/"tor-control")}\nCookieAuthentication 1\nLog notice stdout\n')
                            launch([tor, '-f', str(tor_path)])
                            deadline=time.monotonic()+30
                            while not (runtime/'tor-control').exists():
                                if time.monotonic()>deadline or processes[-1].poll() is not None:
                                    raise RecoverableError('The private Tor instance did not start')
                                time.sleep(.2)
                            control_command += ['--socket', str(runtime/'tor-control')]
                        controller = subprocess.Popen(control_command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True, start_new_session=True)
                        # The controller creates the address and exits if Tor access is denied.
                        import select
                        deadline=time.monotonic()+60
                        line=''
                        while time.monotonic()<deadline:
                            readable,_,_=select.select([controller.stdout],[],[],.5)
                            if readable:
                                line=controller.stdout.readline().strip()
                                break
                            if controller.poll() is not None:
                                break
                        if not re.fullmatch(r'ONION_URL=http://[a-z2-7]{56}\.onion',line):
                            raise RecoverableError('Could not create an onion service. Check that Tails is connected to Tor and that the control socket permits this launcher. Details are in the private runtime log.')
                        url=line.split('=',1)[1]
                        print('\nONION SITE ADDRESS: '+url, flush=True)
                        print('Admin: '+url+'/admin.php', flush=True)
                        print('Saved address: '+str(storage/'onion/hostname'), flush=True)
                        print('Tor may take a few minutes to publish the address. Open it in Tor Browser to check reachability.', flush=True)
                        print('Keep this terminal and computer running. Press Ctrl+C to stop hosting.\n', flush=True)
                        write_status(storage,'running',url=url,children={**{Path(p.args[0]).name:p.pid for p in processes},'controller':controller.pid})
                        failures=0;next_health=time.monotonic()+HEALTH_INTERVAL
                        while True:
                            if controller.poll() is not None or any(p.poll() is not None for p in processes):
                                raise RecoverableError('A managed process stopped unexpectedly')
                            if time.monotonic()>=next_health:
                                failures=0 if healthy_http(port) else failures+1
                                if failures>=3:raise RecoverableError('The local storefront failed three consecutive health checks')
                                write_status(storage,'running',url=url,children={**{Path(p.args[0]).name:p.pid for p in processes},'controller':controller.pid},health_failures=failures)
                                next_health=time.monotonic()+HEALTH_INTERVAL
                            time.sleep(MONITOR_INTERVAL)
                    finally:
                        if controller:
                            if controller.stdin:
                                controller.stdin.close()
                            try:
                                controller.wait(timeout=12)
                            except subprocess.TimeoutExpired:
                                os.killpg(controller.pid, signal.SIGTERM)
                                controller.wait(timeout=5)
                        for process in reversed(processes):stop_owned_group(process)
                        # Show useful startup diagnostics before deleting runtime files.
                        if sys.exc_info()[0] not in (None, KeyboardInterrupt):
                            for name in ('processes.log','nginx-error.log','php-errors.log'):
                                path=runtime/name
                                if path.exists():
                                    print(name+':\n'+path.read_text(errors='replace')[-4000:],file=sys.stderr)
            budget=RestartBudget()
            try:
                while True:
                    check_persistent_state(storage)
                    # Only our private runtime sockets may be removed, after all
                    # owned children from the previous attempt have stopped.
                    for name in ('php.sock','tor-control'):(runtime/name).unlink(missing_ok=True)
                    write_status(storage,'starting')
                    try:
                        serve_attempt()
                    except RecoverableError as error:
                        check_persistent_state(storage)
                        delay=budget.next_delay()
                        write_status(storage,'recovering',last_error=str(error),retry_delay=delay)
                        print(f'Recovering managed services in {delay}s: {error}. Saved data and onion keys are unchanged.',flush=True)
                        time.sleep(delay)
            except KeyboardInterrupt:
                write_status(storage,'stopped');raise
            except Exception as error:
                write_status(storage,'failed',last_error=str(error));raise



if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        main()
    except KeyboardInterrupt:
        print('\nHosting stopped. The saved onion identity and store data have been kept.')
    except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as error:
        print('Hosting failed: '+str(error),file=sys.stderr)
        sys.exit(1)
