#!/bin/sh
# Tails launcher; Debian/Ubuntu are also supported for local validation.
set -eu
export PATH="$PATH:/usr/sbin:/sbin"
cd -- "$(dirname -- "$0")"
project_dir=$(pwd -P)
case "${1:-}" in
 --help|-h)
  cat <<'HELP'
BitCart onion hosting for Tails (also Debian/Ubuntu)
  sh host-onion.sh             Install missing requirements and start hosting
  sh host-onion.sh --check     Check prerequisites without installing/publishing
  sh host-onion.sh --status    Show the managed server status and onion address
  sh host-onion.sh --stop      Stop this store cleanly
  sh host-onion.sh --restart   Restart this store with the same onion identity
On Tails: set an administration password at the Welcome Screen, unlock
Persistent Storage, and connect to Tor before starting. Run as the normal user.
Desktop and application-menu shortcuts are created automatically.
BITCART_STORAGE_DIR selects private storage; BITCART_PORT defaults to 8080.
HELP
  exit 0;;
 ''|--check|--status|--stop|--restart) ;;
 *) echo 'Unknown option. Use sh host-onion.sh --help.' >&2; exit 1;;
esac
[ "$(uname -s)" = Linux ] || { echo 'Run on Linux.' >&2; exit 1; }
[ "$(id -u)" != 0 ] || { echo 'Run as your normal desktop user. The launcher uses sudo only where needed.' >&2; exit 1; }
case "${1:-}" in
 --check|--status|--stop) ;;
 *)
  missing=0
  for executable in python3 nginx tor; do command -v "$executable" >/dev/null 2>&1 || missing=1; done
  php_binary=''
  for executable in php; do
   if command -v "$executable" >/dev/null 2>&1 && "$executable" -r 'exit(PHP_VERSION_ID>=80100 && extension_loaded("pdo_sqlite") && extension_loaded("mbstring") && extension_loaded("session") && function_exists("getimagesize") ? 0 : 1);' 2>/dev/null; then
    version=$("$executable" -r 'echo PHP_MAJOR_VERSION,".",PHP_MINOR_VERSION;')
    if command -v "php-fpm$version" >/dev/null 2>&1; then php_binary=$executable; break; fi
   fi
  done
  [ -n "$php_binary" ] || missing=1
  if [ "$missing" = 1 ]; then
   command -v apt-get >/dev/null 2>&1 || { echo 'Automatic setup supports Tails, Debian and Ubuntu.' >&2; exit 1; }
   command -v sudo >/dev/null 2>&1 || { echo 'Sudo is required. On Tails, set an administration password at the Welcome Screen.' >&2; exit 1; }
   echo 'Installing PHP/nginx requirements from the configured Debian repositories.'
   sudo /bin/bash "$project_dir/scripts/install-linux.sh"
  fi;;
esac
command -v python3 >/dev/null || { echo 'Python 3 is missing. Start without management options to install requirements.' >&2; exit 1; }
exec python3 "$project_dir/scripts/host_onion.py" "$@"
