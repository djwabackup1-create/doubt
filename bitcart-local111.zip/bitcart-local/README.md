# BitCart — Local Bitcoin-only Store MVP

A small, customer-account-free e-commerce starter using PHP, SQLite, HTML, CSS, and vanilla JavaScript.

## Requirements
- PHP 8.1+ with PDO SQLite and mbstring enabled
- A browser
- A Bitcoin receiving wallet address (no payment processor or API key required)

## Run locally on Windows
1. Install PHP 8.1+ and ensure `php.exe` is on PATH.
2. Extract this project to a folder, for example `C:\bitcart-local`.
3. Open PowerShell in that folder.
4. Run:
   ```powershell
   php -S 127.0.0.1:8000 -t public
   ```
5. Open `http://127.0.0.1:8000/setup.php` once.
6. Set a unique admin password. Setup writes a password hash to `config.php` in the configured storage directory.
7. Delete `public/setup.php` after setup.
8. Open `http://127.0.0.1:8000`.

### If PHP reports a missing PHP extension

The PHP executable serving the site must load PDO SQLite. Check which INI file it uses with `php --ini`. In that file, enable these settings (adjust `extension_dir` to your PHP installation):

```ini
extension_dir="C:\php\ext"
extension=pdo_sqlite
extension=sqlite3
extension=mbstring
```

If `php --ini` says no configuration file is loaded, create `php.ini` in the PHP installation directory. Confirm SQLite is available with `php -r "var_export(PDO::getAvailableDrivers());"`; the output must include `sqlite`. Restart the PHP server after changing the INI file.

SQLite data is stored in `storage/store.sqlite`. Keep `storage/` private and never serve it directly.

## Persistent storage

By default, the database and private configuration files are stored in the project's `storage/` directory. To keep them somewhere else, set `BITCART_STORAGE_DIR` to a private, writable directory before starting PHP. The database, admin password hash, product images and private payment screenshots all use this directory.

## Start onion hosting on Tails

The included launcher installs missing PHP/nginx packages from the configured Debian repositories, configures a localhost-only nginx + PHP-FPM server, creates a Tor v3 onion service, and prints its address. Manual Bitcoin payments do not need BTCPay Server or Bitcoin Core.

1. At the Tails Welcome Screen, set an **Administration Password** and unlock **Persistent Storage**.
2. Connect Tails to Tor normally and wait for the connection to succeed.
3. Copy this entire project folder into `~/Persistent/bitcart-local`. Keep `storage/`, including your database and uploaded images, with the project.
4. Open a terminal in that folder and run:

   ```bash
   sh host-onion.sh
   ```

5. Enter the Tails administration password when `sudo` asks. The first run downloads any missing server packages. If no store admin password exists, the launcher asks you to create one **before** exposing the site. Existing store credentials are retained.
6. The terminal prints **ONION SITE ADDRESS: http://…onion** and the Admin URL. Open it in Tor Browser; publication can take a few minutes. Configure your Bitcoin address and USD/BTC rate in Admin if you have not already done so.

The first successful launch creates **Start BitCart.desktop** and **Stop BitCart.desktop** on your Desktop, in the application menu, and in the project folder for subsequent clicks. The shortcuts retain your private storage directory and port settings. Your file manager might require **Allow Launching** or **Run as a Program** once. Moving the project requires running `sh host-onion.sh` again to regenerate that shortcut.

Keep the terminal and Tails running while hosting. **Ctrl+C** stops the site. The same onion address is reused on the next launch because `storage/onion/private_key` is retained. The displayed hostname is also saved in `storage/onion/hostname`. Back up this key with your private store data; losing it loses that onion address. Never put `storage/` inside `public/` or share the private key.

On Tails the launcher authenticates to the existing Tor control socket using sudo, then drops root privileges before handling store data or onion keys. It does not rewrite Tails' Tor configuration, disable onion-grater, start a second Tor instance, or change firewall rules. It fails with a diagnostic if the installed Tails version does not permit this custom controller. This is a custom hosting setup, not an officially supported Tails hosting feature, and has not been tested on an actual Tails installation. Tails shutdown or sleep interrupts hosting; this is not an unattended, always-on deployment.

On the first install, choose **Install Only Once** if Tails asks about automatically reinstalling the server packages. Let this launcher install missing packages on each session: it suppresses service startup during installation so a default system nginx does not bind public interfaces. Do not separately configure automatic default nginx service startup. Existing unrelated nginx/Tor deployments are not changed by the installer.

The same command supports Debian/Ubuntu. There it starts its own Tor process with private state, while nginx remains bound to `127.0.0.1` only. No router port forwarding is needed. Private runtime logs and sessions are temporary, and access logging is disabled. The package installer needs sudo for missing dependencies; the web application does not run as root.

To check prerequisites without installing packages or creating a service:

```bash
sh host-onion.sh --check
```

Manage the running store from the shortcuts, or from its folder:

```bash
sh host-onion.sh --status
sh host-onion.sh --stop
sh host-onion.sh --restart
```

The supervisor checks the local storefront every 15 seconds and recovers owned processes after a crash or three consecutive failed checks. Recovery backs off and stops after five restarts in ten minutes. It reuses the saved onion identity and does not reset the database, payment approvals, or uploaded files. A damaged database or lost/damaged onion key stops hosting for manual repair. Before startup/migration, a healthy existing database is backed up under `storage/backups/`, retaining the three latest pre-start snapshots. Backups are not restored automatically.

On Tails, recovery reconnects to the existing Tor service; it does not restart or reconfigure Tails' Tor. If sudo authorization has expired or the control socket is unavailable, recovery eventually stops rather than weakening permissions. Start the launcher again to authorize access. All runtime recovery ends when you stop the launcher or shut down Tails.

Set `BITCART_PORT` to change the local HTTP port (default `8080`), or `BITCART_STORAGE_DIR` to use another private store directory. On Tails, both the project and store directory must be inside unlocked `~/Persistent`. The generated server blocks `/setup.php` and serves only `public/`; setup is handled locally by the launcher. PHP is configured for 10 MB uploads and a 12 MB request limit.

This workspace can prepare and test the files, but running the launcher on your Tails machine is what creates and publishes its real onion address.

Sources: [Tails additional software and persistence](https://tails.net/doc/persistent_storage/additional_software/index.en.html), [Tor onion-service control commands](https://spec.torproject.org/control-spec/commands.html#add_onion).

## Admin
The storefront has a discreet “Admin” link in the footer. Admin authentication is still required. Admin features: add/edit/delete products, stock, and order status viewing.

Add product images using the **Upload product image** file picker. Images are stored locally rather than loaded from an external URL. Supported raster formats are JPG, PNG, GIF, WebP, AVIF, BMP, ICO and TIFF, up to 10 MB and 40 megapixels. SVG and unsupported formats such as HEIC must be exported to JPG or PNG first. Browser previews depend on browser format support. Keep or remove the current image when editing.

Set PHP's `upload_max_filesize=10M` and `post_max_size=12M` in `php.ini` to permit the full 10 MB limit, then restart PHP. A lower PHP or web server limit takes precedence.

## USD prices and manual Bitcoin payments

1. Open **Admin → Bitcoin payment settings**.
2. Paste your own Bitcoin mainnet receiving address. Legacy, SegWit and Taproot addresses are checked for valid checksums. Never enter recovery words or a private key.
3. Enter the USD value of **1 BTC**, then save. Update this rate yourself; no external exchange-rate service is called.
4. Add products in **USD** (the default), or select BTC for a fixed BTC price.
5. Customers follow the existing flow: shop → cart → checkout → Bitcoin payment page. At checkout they enter their chosen name and one contact method (email, phone or messaging handle). Delivery address, city and note are optional.
6. Checkout fixes the BTC total and receiving address for that order. The payment page displays the exact BTC amount, address and a QR code generated locally. Later rate or address changes do not change an existing order's payment instructions.
7. After paying, the customer enters their name or chosen alias, uploads a screenshot and clicks **Submit payment for review**. The order becomes `payment_review`; submitting a screenshot never approves payment automatically.
8. Open **Admin → Recent orders → Review order** to see the screenshot, contact information, payer name, ordered items and receiving address. Check receipt in your own wallet, then select **Approve payment** and update the order. Processing and shipping require approval first.

A shared receiving address and screenshots require careful manual matching: screenshots alone cannot prove payment. Customers can use their private order link to check approval and order status; an open payment page checks for status changes every 15 seconds. Screenshots can only be viewed by a logged-in admin. BTCPay is no longer used and its old webhook returns HTTP 410.

No customer accounts, analytics or third-party QR/image services are used. Contact details are only submitted when placing an order. Cart and wishlist stay in browser storage; the application uses an essential session cookie for forms and admin access. Your hosting server may retain its own access logs. Back up private storage and remove old order data according to your retention needs.

Existing INR products remain marked as legacy and hidden from the shop until you enter a new USD or BTC price in Admin. Existing orders keep their original records; they are not relabelled as BTC. The database retains some legacy column names for compatibility.

## Local checks

Product cards offer quantity selection. Adding opens the cart with immediate totals; the cart supports plus/minus, typed quantities, remove, and clear. Storefront prices and stock refresh every 15 seconds and when the page regains focus. Checkout checks current prices and stock again on the server. Identical submissions from the same session within five minutes reuse the saved order.

New orders reserve inventory immediately, including orders waiting for screenshots or manual review. Cancel abandoned orders from Admin to release their stock; reservations do not expire automatically. Cancelling twice does not restore stock twice, and reopening a cancelled order checks and reserves stock again. Existing orders created before this change do not retroactively reserve inventory.

Run `python tests/smoke.py` for isolated HTTP integration checks (requires Python 3 and PHP on PATH), and `node tests/frontend.cjs` for JavaScript behavior checks (requires Node.js). The HTTP checks create temporary storage and do not change your store data. These checks do not replace visual browser testing or a real wallet payment.

Run `python tests/browser.py` for the actual Chromium cart-to-checkout flow. It requires Python's `websockets` package and Chromium; set `BITCART_CHROME` to your Chromium executable if it is not in the default local Playwright cache. It also uses temporary store data.

Run `php tests/addresses.php` to check mainnet address validation against legacy, SegWit and Taproot vectors.

Hosting checks: `python tests/hosting.py` validates configurations, persistence requirements and Tor control behavior. On Linux with the installed server dependencies, `python3 tests/hosting_linux.py` exercises real nginx, PHP-FPM, Tor key generation, the complete launcher, and clean restarts. Its Tor networking is disabled, so it never publishes a test site.

For the isolated privileged-controller test, run `sudo python3 tests/hosting_privileges_linux.py --uid "$(id -u)" --gid "$(id -g)"` from your normal user. It verifies root-only socket access and the privilege drop using a temporary Tor instance with networking disabled; it does not touch system Tor.

## QR library

The locally bundled `public/assets/vendor/qrcodegen.js` is Project Nayuki's QR Code generator under the MIT license; its license notice is included in the file. Address QR generation makes no network request.
