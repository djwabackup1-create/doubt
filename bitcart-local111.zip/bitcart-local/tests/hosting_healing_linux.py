"""Fault-injection checks for the real supervisor; Tor networking stays disabled."""
from contextlib import closing
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('host',ROOT/'scripts/host_onion.py')
host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
checks=0
def check(value,label):
    global checks
    assert value,label
    checks+=1;print('PASS',label,flush=True)

WRAPPER='''
import importlib.util,pathlib,subprocess,sys,signal
spec=importlib.util.spec_from_file_location('launcher',sys.argv[1]);launcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(launcher)
original=subprocess.Popen
def isolated(command,*args,**kwargs):
    if pathlib.Path(command[0]).name=='tor':command=list(command)+['--DisableNetwork','1']
    return original(command,*args,**kwargs)
subprocess.Popen=isolated
launcher.HEALTH_INTERVAL=.3;launcher.MONITOR_INTERVAL=.1
original_delay=launcher.RestartBudget.next_delay
def quick_delay(self):original_delay(self);return .2
launcher.RestartBudget.next_delay=quick_delay
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt()))
sys.argv=[sys.argv[0]]+sys.argv[2:]
try:launcher.main()
except KeyboardInterrupt:pass
'''

with tempfile.TemporaryDirectory(prefix='bitcart-healing-',dir='/tmp') as folder:
    base=Path(folder);base.chmod(0o700)
    project=base/'Store Files';project.mkdir()
    for name in ('scripts','public','src'):shutil.copytree(ROOT/name,project/name)
    shutil.copy2(ROOT/'host-onion.sh',project/'host-onion.sh')
    storage=base/'private';storage.mkdir(mode=0o700)
    php=host.find_tools()[0]
    config=subprocess.check_output([php,'-r','echo "<?php return [\'password_hash\'=>".var_export(password_hash("Synthetic-test-password-123!",PASSWORD_DEFAULT),true)."];";'],text=True)
    (storage/'config.php').write_text(config)
    with closing(sqlite3.connect(storage/'store.sqlite')) as connection:
        connection.execute('CREATE TABLE canary(value TEXT)');connection.execute("INSERT INTO canary VALUES('preserve me')");connection.commit()
    proofs=storage/'uploads/proofs';proofs.mkdir(parents=True);(proofs/'canary.bin').write_bytes(b'preserve screenshot')
    home=base/'home';home.mkdir()
    with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
    environment=dict(os.environ,HOME=str(home),BITCART_STORAGE_DIR=str(storage),BITCART_PORT=str(port))
    processes=[];logs=[]
    def launch(*args):
        log=(base/f'launch-{len(processes)}.log').open('w');logs.append(log)
        process=subprocess.Popen([sys.executable,'-u','-c',WRAPPER,str(project/'scripts/host_onion.py'),*args],env=environment,stdout=log,stderr=log)
        processes.append(process);return process
    def status():
        try:return json.loads((storage/'hosting-status.json').read_text())
        except (OSError,ValueError):return {}
    def wait(predicate,timeout=25):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            value=status()
            if predicate(value):return value
            time.sleep(.05)
        raise AssertionError('Supervisor did not reach expected state: '+str(status()))
    def role(value,prefix):return next(pid for name,pid in value['children'].items() if name.startswith(prefix))
    def management(option):
        return subprocess.run([sys.executable,str(project/'scripts/host_onion.py'),option],env=environment,capture_output=True,text=True,timeout=45)
    try:
        process=launch();current=wait(lambda s:s.get('state')=='running' and s.get('pid')==process.pid)
        address=current['url'];key=(storage/'onion/private_key').read_bytes()
        check(host.healthy_http(port),'Initial storefront is healthy')
        for prefix in ('php-fpm','nginx','tor'):
            old=role(current,prefix);os.kill(old,signal.SIGKILL)
            current=wait(lambda s:s.get('state')=='running' and role(s,prefix)!=old)
            check(host.healthy_http(port),prefix+' crash automatically recovers the storefront')
            check(current['url']==address and (storage/'onion/private_key').read_bytes()==key,'Recovery preserves the onion identity after '+prefix+' failure')
        # Exercise the HTTP watchdog without a process exit.
        index=project/'public/index.php';original=index.read_bytes();old=current['children']['controller']
        index.write_bytes(b"<?php http_response_code(503);exit('synthetic health failure'); ?>")
        wait(lambda s:s.get('state')=='recovering');index.write_bytes(original)
        current=wait(lambda s:s.get('state')=='running' and s['children']['controller']!=old)
        check(host.healthy_http(port),'Three failed HTTP health checks trigger safe recovery')
        old=current['children']['controller'];os.kill(old,signal.SIGKILL)
        current=wait(lambda s:s.get('state')=='running' and s['children']['controller']!=old)
        check(current['url']==address,'Onion controller crash recovers with the same address')
        os.kill(role(current,'nginx'),signal.SIGKILL)
        wait(lambda s:s.get('state')=='failed');process.wait(timeout=20)
        check(process.returncode!=0 and not host.healthy_http(port),'Restart storm exhausts the budget and closes the storefront')
        check('Recovery limit' in status().get('last_error',''),'Stopped state records an actionable recovery-limit error')
        process=launch();current=wait(lambda s:s.get('state')=='running' and s.get('pid')==process.pid)
        result=management('--status')
        check(result.returncode==0 and address in result.stdout and 'running' in result.stdout,'Status management command reports the correct service')
        duplicate=launch();duplicate.wait(timeout=10)
        check(duplicate.returncode==0 and status()['pid']==process.pid,'Second start does not create a duplicate service')
        restarted=launch('--restart');current=wait(lambda s:s.get('state')=='running' and s.get('pid')==restarted.pid,timeout=40)
        process.wait(timeout=10)
        check(process.returncode==0 and current['url']==address,'Restart management cleanly replaces the supervisor without changing the address')
        result=management('--stop');restarted.wait(timeout=10)
        check(result.returncode==0 and restarted.returncode==0 and not host.healthy_http(port),'Stop management closes all owned services cleanly')
        with closing(sqlite3.connect(storage/'store.sqlite')) as connection:check(connection.execute('SELECT * FROM canary').fetchall()==[('preserve me',)],'Database content survives crashes and management commands')
        check((proofs/'canary.bin').read_bytes()==b'preserve screenshot' and (storage/'onion/private_key').read_bytes()==key,'Uploaded proof and private onion key remain unchanged')
        for path in (home/'Desktop').glob('*.desktop'):
            result=subprocess.run(['desktop-file-validate',str(path)],capture_output=True,text=True)
            check(result.returncode==0,'Desktop shortcut validates: '+path.name)
        print(f'{checks} recovery and management checks passed; no site was published.',flush=True)
    except Exception:
        for path in base.glob('launch-*.log'):print(path.name+':\n'+path.read_text(errors='replace')[-6000:])
        raise
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=30)
                except subprocess.TimeoutExpired:process.kill();process.wait()
        for log in logs:log.close()
