"""Linux-only integration check of real nginx, PHP-FPM and Tor (network disabled).

Uses a temporary copy and synthetic admin password. No onion is published and
the real store, onion keys and system service configuration are untouched.
"""
import getpass
import grp
import http.cookiejar
import importlib.util
import os
from pathlib import Path
import pwd
import queue
import re
import select
import shutil
import socket
import subprocess
import signal
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/f'{name}.py')
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
host=module('host_onion');tor_module=module('tor_service')
checks=0
def check(value,label):
    global checks
    assert value,label
    checks+=1;print('PASS',label,flush=True)

def main():
    php,fpm,nginx,tor=host.find_tools()
    with tempfile.TemporaryDirectory(prefix='bitcart-integration-',dir='/tmp') as folder:
        base=Path(folder);base.chmod(0o700)
        project=base/'Store Files';project.mkdir()
        for name in ('public','src'):shutil.copytree(ROOT/name,project/name)
        storage=base/'private';storage.mkdir(mode=0o700)
        runtime=base/'run';runtime.mkdir(mode=0o700)
        for name in ('uploads','sessions','client-body','fastcgi-temp','proxy-temp','scgi-temp','uwsgi-temp'):(runtime/name).mkdir(mode=0o700)
        password='Temporary-Linux-check-123!'
        config=subprocess.check_output([php,'-r','echo "<?php return [\'password_hash\'=>".var_export(password_hash(stream_get_contents(STDIN),PASSWORD_DEFAULT),true)."];";'],input=password,text=True)
        (storage/'config.php').write_text(config)
        with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
        fpm_config=runtime/'php-fpm.conf';fpm_config.write_text(host.fpm_config(storage,runtime,pwd.getpwuid(os.getuid()).pw_name,grp.getgrgid(os.getgid()).gr_name))
        nginx_config=runtime/'nginx.conf';nginx_config.write_text(host.nginx_config(project,runtime,port))
        (project/'public/probe.php').write_text('<?php echo json_encode([ini_get("upload_max_filesize"),ini_get("post_max_size"),ini_get("display_errors"),getenv("BITCART_STORAGE_DIR")]);')
        processes=[]
        with (runtime/'test.log').open('w') as log:
            try:
                subprocess.run([fpm,'-t','-y',str(fpm_config)],check=True,stdout=log,stderr=log)
                subprocess.run([nginx,'-t','-p',str(runtime)+'/', '-c',str(nginx_config)],check=True,stdout=log,stderr=log)
                check(True,'Real nginx and PHP-FPM configuration validation')
                for command in ([fpm,'-F','-y',str(fpm_config)],[nginx,'-p',str(runtime)+'/','-c',str(nginx_config)]):processes.append(subprocess.Popen(command,stdout=log,stderr=log))
                host.wait_http(port,processes)
                client=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
                def request(path,data=None):
                    if data is not None:data=urllib.parse.urlencode(data).encode()
                    try:response=client.open(f'http://127.0.0.1:{port}'+path,data=data,timeout=5)
                    except urllib.error.HTTPError as error:response=error
                    return response.status,response.read().decode(),response.headers
                status,html,headers=request('/')
                check(status==200 and 'BITCART_PRODUCTS' in html and '<?php' not in html,'PHP storefront executes behind nginx')
                check(headers.get('Referrer-Policy')=='no-referrer' and headers.get('X-Content-Type-Options')=='nosniff','Privacy and content-type response headers')
                for path in ('/storage/config.php','/src/bootstrap.php','/.git/config','/setup.php'):
                    check(request(path)[0] in (403,404),'Private or setup path blocked: '+path)
                status,html,_=request('/admin-login.php')
                token=re.search(r'name="csrf" value="([^"]+)"',html)[1]
                check('Store management' in request('/admin-login.php',dict(csrf=token,password=password))[1],'Real PHP-FPM admin login and session persistence')
                import json
                settings=json.loads(request('/probe.php')[1])
                check(settings[0]=='10M' and settings[1]=='12M' and settings[2] in ('','0') and settings[3]==str(storage),'Upload limits, hidden errors and private storage environment')
                # Tor creates keys locally while DisableNetwork prevents descriptor publication.
                tor_state=base/'tor-state';tor_state.mkdir(mode=0o700)
                tor_socket=runtime/'tor-control'
                tor_config=runtime/'torrc'
                tor_config.write_text(f'DataDirectory {host.quoted(tor_state)}\nSocksPort 0\nDisableNetwork 1\nCookieAuthentication 1\nControlSocket {host.quoted(tor_socket)}\n')
                tor_process=subprocess.Popen([tor,'-f',str(tor_config)],stdout=log,stderr=log);processes.append(tor_process)
                deadline=time.monotonic()+20
                while not tor_socket.exists():
                    if tor_process.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Test Tor failed to start')
                    time.sleep(.1)
                controller=tor_module.Controller(tor_socket);controller.authenticate()
                address=tor_module.register(controller,storage/'onion',port)
                check(bool(re.fullmatch('[a-z2-7]{56}\\.onion',address)),'Real Tor generates a v3 onion identity locally')
                secret=(storage/'onion/private_key').read_bytes()
                check((storage/'onion/private_key').stat().st_mode & 0o777 == 0o600,'Onion private key is owner-readable only')
                check(address[:-6] in '\n'.join(controller.command('GETINFO onions/current')),'Onion service belongs to its control connection')
                controller.close()
                # A second connection reuses the same persisted identity.
                controller=tor_module.Controller(tor_socket);controller.authenticate()
                check(address[:-6] not in '\n'.join(controller.command('GETINFO onions/current')),'Closing the controller removes the running service')
                second=tor_module.register(controller,storage/'onion',port)
                check(second==address and (storage/'onion/private_key').read_bytes()==secret,'Restart preserves the real onion address and key')
                controller.close()
                check(not (runtime/'nginx-access.log').exists(),'No nginx access log generated')
                print(f'{checks} real Linux stack checks passed; Tor networking was disabled.',flush=True)
            except Exception:
                for path in runtime.glob('*.log'):
                    print(path.name+':\n'+path.read_text(errors='replace')[-5000:])
                raise
            finally:
                for process in reversed(processes):
                    if process.poll() is None:
                        process.terminate()
                        try:process.wait(timeout=10)
                        except subprocess.TimeoutExpired:process.kill();process.wait()
        # Run the actual orchestrator twice. Only the test wrapper forces Tor's
        # DisableNetwork option; the distributed launcher has no test backdoor.
        shutil.copytree(ROOT/'scripts',project/'scripts')
        shutil.copy2(ROOT/'host-onion.sh',project/'host-onion.sh')
        wrapper='''
import importlib.util, pathlib, subprocess, sys, signal
spec=importlib.util.spec_from_file_location('launcher',sys.argv[1])
launcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(launcher)
original=subprocess.Popen
def isolated(command,*args,**kwargs):
    if pathlib.Path(command[0]).name=='tor':command=list(command)+['--DisableNetwork','1']
    return original(command,*args,**kwargs)
subprocess.Popen=isolated
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt()))
sys.argv=[sys.argv[0]]
try:launcher.main()
except KeyboardInterrupt:pass
'''
        addresses=[]
        (base/'home').mkdir()
        for iteration in range(2):
            environment=dict(os.environ,HOME=str(base/'home'),BITCART_STORAGE_DIR=str(storage),BITCART_PORT=str(port))
            process=subprocess.Popen([sys.executable,'-u','-c',wrapper,str(project/'scripts/host_onion.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=environment)
            output=[]
            lines=queue.Queue()
            def read_lines():
                for line in process.stdout:lines.put(line)
                lines.put(None)
            reader=threading.Thread(target=read_lines,daemon=True);reader.start()
            try:
                deadline=time.monotonic()+30
                while time.monotonic()<deadline:
                    try:line=lines.get(timeout=.5)
                    except queue.Empty:continue
                    if line is None:break
                    output.append(line)
                    if line.startswith('ONION SITE ADDRESS: '):
                        addresses.append(line.strip().split(': ',1)[1]);break
                check(len(addresses)==iteration+1,'Complete launcher prints a real onion address (run '+str(iteration+1)+')')
                check((project/'Start BitCart.desktop').is_file(),'Clickable desktop launcher generated')
            except Exception:
                print(''.join(output));raise
            finally:
                if process.poll() is None:process.send_signal(signal.SIGTERM)
                process.wait(timeout=25);reader.join(timeout=2)
                while not lines.empty():
                    remaining=lines.get()
                    if remaining is not None:output.append(remaining)
                if process.returncode:print(''.join(output))
                check(process.returncode==0,'Launcher shuts down cleanly')
            with socket.socket() as probe:
                check(probe.connect_ex(('127.0.0.1',port))!=0,'Local storefront port closed after shutdown')
        check(addresses[0]==addresses[1],'Complete launcher restart retains its onion address')
        print(f'{checks} total Linux integration checks passed; no test site was published.')

if __name__=='__main__':main()
