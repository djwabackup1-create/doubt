<?php
return ['password_hash' => '$2y$12$WFOkcpXkjk8kpgF4jE0p8ej0YgIxBcMbd6hBm8AW9awLSlQHYtO.2'];
