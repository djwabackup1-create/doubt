// Run without dependencies: node tests/frontend.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
let checks = 0;
function check(value, label) { assert.ok(value, label); console.log('PASS', label); checks++; }
function environment(file, stored = {}) {
  const elements = {};
  function element(id) {
    return elements[id] ||= { hidden: true, value: '', dataset: {}, listeners: {}, classList: { add() {}, remove() {}, toggle() {} },
      addEventListener(type, fn) { this.listeners[type] = fn; },
      setCustomValidity(message) { this.validityMessage = message; }, removeAttribute(name) { delete this[name]; },
      querySelector() { return element('submit'); }, reportValidity() { return true; } };
  }
  const document = { getElementById: element, querySelectorAll: () => [], body: element('body'), listeners: {}, addEventListener(type, fn) { this.listeners[type] = fn; } };
  const context = { document, window: { addEventListener() {}, BITCART_PRODUCTS: [{ id: 1, name: '<Goods>', price: 123.45, stock: 2 }] },
    localStorage: { getItem: key => stored[key] ?? null, setItem: (key, value) => stored[key] = value, removeItem: key => delete stored[key] },
    location: {}, URL: class extends URL { static createObjectURL() { return 'blob:test-image'; } static revokeObjectURL() {} }, setTimeout, clearTimeout, setInterval() {}, alert() {}, FormData: class { get(key) { return key === 'csrf' ? 'token' : 'test'; } },
    fetch: async () => ({ ok: true, json: async () => ({ ok: true, url: '/payment.php?order=1&ref=test' }) }) };
  if (file !== 'admin.js') vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../public/assets/cart.js'), 'utf8'), context);
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../public/assets', file), 'utf8'), context);
  return { context, elements, stored, element, click(button) { button.closest ||= () => null; button.classList ||= { contains: () => false }; document.listeners.click({ target: { closest: () => button } }); } };
}
(async () => {
  const app = environment('app.js');
  app.click({ dataset: { add: '1' } });
  check(JSON.parse(app.stored.bitcart_cart_v1)[0].qty === 1, 'Add product to cart');
  check(app.elements.cartDrawer.hidden === false && app.elements.cartStatus.textContent.includes('Added'), 'Add opens cart with confirmation');
  app.click({ dataset: { add: '1' } });
  app.click({ dataset: { plus: '1' } });
  check(JSON.parse(app.stored.bitcart_cart_v1)[0].qty === 2, 'Cart respects stock limit');
  check(app.elements.cartItems.innerHTML.includes('&lt;Goods&gt;'), 'Cart escapes product names');
  app.click({ dataset: { wish: '1' } });
  check(JSON.parse(app.stored.bitcart_wishlist_v1)[0] === 1, 'Wishlist saves product');
  app.click({ dataset: { unwish: '1' } });
  check(JSON.parse(app.stored.bitcart_wishlist_v1).length === 0, 'Wishlist removes product');
  app.click({ dataset: {}, id: 'openCart', classList: { contains: () => false } });
  check(app.elements.cartDrawer.hidden === false, 'Cart drawer opens');
  app.elements.checkoutButton.listeners.click();
  check(app.context.location.href === '/checkout.php', 'Cart continues to checkout');
  app.click({ dataset: { remove: '1' } });
  check(JSON.parse(app.stored.bitcart_cart_v1).length === 0, 'Cart removes product');
  app.click({ dataset: { add: '1' } });
  app.click({ dataset: { minus: '1' } });
  check(JSON.parse(app.stored.bitcart_cart_v1).length === 0, 'Minus removes last unit');
  app.click({ dataset: { add: '1' } });
  app.context.document.listeners.change({target:{dataset:{quantity:'1'},value:'999'}});
  check(JSON.parse(app.stored.bitcart_cart_v1)[0].qty === 2, 'Typed quantity is clamped to stock');
  app.click({dataset:{},id:'clearCart'});
  check(JSON.parse(app.stored.bitcart_cart_v1).length === 0 && app.elements.checkoutButton.disabled, 'Clear cart disables checkout');
  app.context.document.listeners.keydown({key:'Escape'});
  check(app.elements.cartDrawer.hidden, 'Escape closes drawer');
  for (const value of ['null', '{}', 'broken', '[null,{"id":1,"qty":-2},{"id":999,"qty":1}]']) {
    const corrupt = environment('app.js', {bitcart_cart_v1:value,bitcart_wishlist_v1:'null'});
    check(corrupt.elements.cartCount.textContent === 0, 'Malformed saved cart handled: '+value);
    corrupt.click({dataset:{add:'1'}});
    check(JSON.parse(corrupt.stored.bitcart_cart_v1)[0].qty === 1, 'Add recovers after malformed storage');
  }
  const checkout = environment('checkout.js', { bitcart_cart_v1: JSON.stringify([{ id: 1, qty: 2 }]) });
  check(checkout.elements.checkoutTotal.textContent.includes('246.90'), 'Checkout renders correct total');
  await checkout.elements.checkoutForm.listeners.submit({ preventDefault() {} });
  check(!checkout.stored.bitcart_cart_v1 && checkout.context.location.href.includes('/payment.php'), 'Successful checkout clears cart and redirects');
  const failed = environment('checkout.js', { bitcart_cart_v1: JSON.stringify([{ id: 1, qty: 1 }]) });
  failed.context.fetch = async () => ({ ok: false, json: async () => ({ error: 'Out of stock' }) });
  await failed.elements.checkoutForm.listeners.submit({ preventDefault() {} });
  check(failed.elements.checkoutMessage.textContent === 'Out of stock' && failed.elements.submit.disabled === false && failed.stored.bitcart_cart_v1, 'Failed checkout keeps cart and permits retry');
  const admin = environment('admin.js');
  admin.elements.imageUpload.files=[{size:100,type:'image/png'}];
  admin.elements.imageUpload.listeners.change();
  check(admin.elements.imagePreview.src==='blob:test-image','Uploaded product image loads local preview');
  admin.elements.imagePreview.onload();
  check(admin.elements.imagePreview.hidden===false,'Loaded upload preview is visible');
  admin.elements.imagePreview.onerror();
  check(admin.elements.imagePreviewStatus.textContent.includes('cannot preview'),'Unsupported browser preview has useful message');
  admin.elements.imageUpload.files=[{size:11*1024*1024,type:'image/png'}];
  admin.elements.imageUpload.listeners.change();
  check(admin.elements.imageUpload.validityMessage.includes('10 MB'),'Oversized image rejected by preview');
  console.log(`${checks} JavaScript checks passed.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
