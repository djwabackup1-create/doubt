"""Dependency-free hosting configuration and Tor controller regression tests."""
import base64
import importlib.util
from pathlib import Path, PurePosixPath
import socket
import shutil
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]


def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/f'{name}.py')
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


host=module('host_onion')
tor=module('tor_service')
KEY='ED25519-V3:'+base64.b64encode(bytes(range(64))).decode()
SERVICE='a'*56


class FakeTor:
    def __init__(self, cookie=None):
        client,self.server=socket.socketpair()
        self.controller=tor.Controller.__new__(tor.Controller)
        self.controller.socket=client
        self.controller.reader=client.makefile('rb')
        self.commands=[]
        self.cookie=cookie
        self.closed=False
        self.worker=threading.Thread(target=self.run,daemon=True)
        self.worker.start()

    def run(self):
        reader=self.server.makefile('rb')
        try:
            for raw in reader:
                command=raw.decode().strip()
                self.commands.append(command)
                if command=='PROTOCOLINFO 1':
                    path=str(self.cookie).replace('\\','\\\\')
                    reply=f'250-PROTOCOLINFO 1\r\n250-AUTH METHODS=COOKIE,SAFECOOKIE COOKIEFILE="{path}"\r\n250 OK\r\n'
                elif command.startswith('ADD_ONION'):
                    reply='250-ServiceID='+SERVICE+'\r\n'
                    if 'NEW:ED25519-V3' in command:
                        reply+='250-PrivateKey='+KEY+'\r\n'
                    reply+='250 OK\r\n'
                elif command.startswith('AUTHENTICATE'):
                    reply='250 OK\r\n'
                else:
                    reply='552 Unknown command\r\n'
                self.server.sendall(reply.encode())
        finally:
            reader.close()
            self.server.close()
            self.closed=True

    def close(self):
        self.controller.close()
        self.worker.join(timeout=2)


class HostingTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which('php'),'PHP CLI not installed')
    def test_first_admin_password_is_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            password='Temporary-strong-password-123!'
            with patch('sys.stdin.isatty',return_value=True),patch.object(host.getpass,'getpass',return_value=password):
                host.ensure_admin(shutil.which('php'),Path(folder))
            result=subprocess.check_output([shutil.which('php'),'-r','$c=require $argv[1];echo password_verify(stream_get_contents(STDIN),$c["password_hash"])?"OK":"FAIL";',str(Path(folder)/'config.php')],input=password,text=True)
            self.assertEqual(result,'OK')
            # A repeat launch validates the existing config without replacing it.
            previous=(Path(folder)/'config.php').read_bytes()
            host.ensure_admin(shutil.which('php'),Path(folder))
            self.assertEqual((Path(folder)/'config.php').read_bytes(),previous)

    def test_localhost_only_nginx(self):
        config=host.nginx_config(PurePosixPath('/home/test/Store Files'),PurePosixPath('/tmp/bitcart-test'),8080)
        self.assertIn('listen 127.0.0.1:8080;',config)
        self.assertNotIn('0.0.0.0',config)
        self.assertIn('root "/home/test/Store Files/public";',config)
        self.assertIn('location = /setup.php { return 404; }',config)
        self.assertIn('access_log off;',config)
        self.assertIn('try_files $uri =404;',config)

    def test_private_php_settings(self):
        config=host.fpm_config(PurePosixPath('/home/test/Persistent/private'),PurePosixPath('/tmp/bitcart-test'),'amnesia','amnesia')
        self.assertIn('env[BITCART_STORAGE_DIR] = "/home/test/Persistent/private"',config)
        self.assertIn('listen.mode = 0600',config)
        self.assertIn('session.use_strict_mode',config)
        self.assertIn('upload_max_filesize] = 10M',config)
        self.assertIn('display_errors] = off',config)

    def test_config_injection_rejected(self):
        with self.assertRaises(RuntimeError): host.quoted('/tmp/a\nlisten 0.0.0.0')
        with self.assertRaises(RuntimeError): host.ini_quoted('/tmp/${SECRET}')
        with self.assertRaises(RuntimeError): host.fpm_config(Path('/tmp'),Path('/tmp'),'bad\nuser','group')

    def test_private_storage_not_public(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            with self.assertRaises(RuntimeError): host.storage_location(root,str(root/'public/uploads'),False,root)

    def test_tails_requires_persistence(self):
        with tempfile.TemporaryDirectory() as temp:
            home=Path(temp)
            with self.assertRaises(RuntimeError): host.storage_location(home/'Downloads/store',None,True,home)
            (home/'Persistent').mkdir()
            with self.assertRaises(RuntimeError): host.storage_location(home/'Downloads/store',None,True,home)
            project=home/'Persistent/store'
            self.assertEqual(host.storage_location(project,None,True,home),(project/'storage').resolve())

    def test_cookie_authentication(self):
        with tempfile.TemporaryDirectory() as temp:
            cookie=Path(temp)/'control.authcookie';cookie.write_bytes(b'x'*32)
            fake=FakeTor(cookie)
            try:
                fake.controller.authenticate()
                self.assertEqual(fake.commands[-1],'AUTHENTICATE '+(b'x'*32).hex())
            finally: fake.close()

    def test_new_key_persisted_and_reused(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)/'onion'
            fake=FakeTor()
            try:
                self.assertEqual(tor.register(fake.controller,directory,8080),SERVICE+'.onion')
                self.assertEqual((directory/'private_key').read_text().strip(),KEY)
                self.assertEqual((directory/'hostname').read_text().strip(),SERVICE+'.onion')
                self.assertIn('Port=80,127.0.0.1:8080',fake.commands[0])
                self.assertNotIn('Detach',fake.commands[0])
                tor.register(fake.controller,directory,8081)
                self.assertTrue(fake.commands[-1].startswith('ADD_ONION '+KEY+' '))
                self.assertIn('127.0.0.1:8081',fake.commands[-1])
            finally: fake.close()
            self.assertTrue(fake.closed)

    def test_missing_key_does_not_change_address(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            (directory/'hostname').write_text(SERVICE+'.onion\n')
            fake=FakeTor()
            try:
                with self.assertRaises(tor.ControlError): tor.register(fake.controller,directory,8080)
                self.assertEqual(fake.commands,[])
            finally: fake.close()

    def test_invalid_saved_key_is_not_replaced(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            (directory/'private_key').write_text('broken key')
            fake=FakeTor()
            try:
                with self.assertRaises(tor.ControlError): tor.register(fake.controller,directory,8080)
                self.assertEqual((directory/'private_key').read_text(),'broken key')
            finally: fake.close()

    def test_controller_rejects_newline_and_error(self):
        fake=FakeTor()
        try:
            with self.assertRaises(tor.ControlError): fake.controller.command('GETINFO a\r\nSIGNAL HALT')
            with self.assertRaises(tor.ControlError): fake.controller.command('UNKNOWN')
        finally: fake.close()


if __name__=='__main__': unittest.main(verbosity=2)
