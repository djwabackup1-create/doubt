<?php
require_once __DIR__.'/../src/commerce.php';
// SegWit vectors: https://github.com/bitcoin/bips/blob/master/bip-0350.mediawiki#test-vectors
$valid=[
    '1BoatSLRHtKNngkdXEeobR76b53LETtpyT',
    '3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy',
    'BC1QW508D6QEJXTDG4Y5R3ZARVARY0C5XW7KV8F3T4',
    'bc1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3qccfmv3',
    'bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7vqzk5jj0',
    'bc1pw508d6qejxtdg4y5r3zarvary0c5xw7kw508d6qejxtdg4y5r3zarvary0c5xw7kt5nd6y',
    'BC1SW50QGDZ25J',
    'bc1zw508d6qejxtdg4y5r3zarvaryvaxxpcs',
];
$invalid=[
    '', 'not an address',
    '1BoatSLRHtKNngkdXEeobR76b53LETtpyX',
    'bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7vqh2y7hd',
    'bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kemeawh',
    'bc1p38j9r5y49hruaue7wxjce0updqjuyyx0kh56v8s25huc6995vvpql3jow4',
    'BC130XLXVLHEMJA6C4DQV22UAPCTQUPFHLXM9H8Z3K2E72Q4K9HCZ7VQ7ZWS8R',
    'bc1pw5dgrnzv',
    'bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7v8n0nx0muaewav253zgeav',
    'BC1QR508D6QEJXTDG4Y5R3ZARVARYV98GJ9P',
    'bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7v07qwwzcrf',
    'bc1gmk9yu',
    'bc1QW508D6QEJXTDG4Y5R3ZARVARY0C5XW7KV8F3T4',
    'tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sl5k7',
];
foreach($valid as $address) if(!valid_bitcoin_address($address)) { fwrite(STDERR,'Valid address rejected: '.$address.PHP_EOL); exit(1); }
foreach($invalid as $address) if(valid_bitcoin_address($address)) { fwrite(STDERR,'Invalid address accepted: '.$address.PHP_EOL); exit(1); }
echo count($valid)+count($invalid).' address validation checks passed.'.PHP_EOL;
