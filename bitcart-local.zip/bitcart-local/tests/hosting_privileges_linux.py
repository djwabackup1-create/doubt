"""Root-only test of the Tails-style privilege drop, with Tor networking off.

Example: sudo python3 tests/hosting_privileges_linux.py --uid 1000 --gid 1000
Uses an isolated Tor process and temporary data; does not touch Tails/system Tor.
"""
import argparse
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import tempfile
import time

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--uid',type=int,required=True)
parser.add_argument('--gid',type=int,required=True)
args=parser.parse_args()
if os.geteuid()!=0 or args.uid<=0 or args.gid<=0:parser.error('Run as root and supply a non-root UID/GID')
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='bitcart-root-check-',dir='/tmp') as folder:
    base=Path(folder);base.chmod(0o711)
    private=base/'root-only';private.mkdir(mode=0o700)
    storage=base/'store';storage.mkdir(mode=0o700);os.chown(storage,args.uid,args.gid)
    torrc=private/'torrc'
    endpoint=private/'control'
    torrc.write_text(f'DataDirectory "{private}/data"\nSocksPort 0\nDisableNetwork 1\nCookieAuthentication 1\nControlSocket "{endpoint}"\n')
    with (private/'test.log').open('w') as log:
        tor=subprocess.Popen([shutil.which('tor'),'-f',str(torrc)],stdout=log,stderr=log)
        helper=None
        try:
            deadline=time.monotonic()+20
            while not endpoint.exists():
                if tor.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Isolated test Tor did not start')
                time.sleep(.1)
            environment=dict(os.environ,SUDO_UID=str(args.uid),SUDO_GID=str(args.gid))
            helper=subprocess.Popen([sys.executable,str(ROOT/'scripts/tor_service.py'),'--socket',str(endpoint),'--storage',str(storage),'--port','8080'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,env=environment)
            ready,_,_=select.select([helper.stdout],[],[],15)
            assert ready,'Privileged helper did not respond'
            line=helper.stdout.readline()
            assert line.startswith('ONION_URL=http://') and '.onion' in line,'Helper failed to create onion service'
            print('PASS Privileged helper authenticates to a root-only Tor control socket')
            key=storage/'onion/private_key'
            assert key.stat().st_uid==args.uid and key.stat().st_gid==args.gid
            print('PASS Helper drops root before writing onion identity files')
            assert key.stat().st_mode & 0o777==0o600
            print('PASS Persisted onion key has private permissions')
            helper.stdin.close();helper.wait(timeout=15)
            assert helper.returncode==0 and tor.poll() is None
            print('PASS Helper exits cleanly without stopping the existing Tor process')
            print('4 privilege checks passed; Tor networking was disabled.')
        except Exception:
            log.flush();print((private/'test.log').read_text(errors='replace')[-4000:]);raise
        finally:
            if helper and helper.poll() is None:helper.terminate();helper.wait(timeout=10)
            tor.terminate();tor.wait(timeout=10)
