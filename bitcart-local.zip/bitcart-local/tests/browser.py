"""Headless Chromium UI regression test. Requires Python websockets and Chromium.
Set BITCART_CHROME to override the executable location.
"""
import base64
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import tempfile
import time
import urllib.request
from websockets.sync.client import connect

ROOT = Path(__file__).resolve().parents[1]
CHROME = os.environ.get('BITCART_CHROME', str(Path(os.environ['LOCALAPPDATA']) / 'ms-playwright/chromium-1248/chrome-win64/chrome.exe'))
def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]

with tempfile.TemporaryDirectory(prefix='bitcart-browser-', ignore_cleanup_errors=True) as folder, tempfile.TemporaryFile() as log:
    http_port, debug_port = port(), port()
    base = f'http://127.0.0.1:{http_port}'
    server = subprocess.Popen(['php', '-S', f'127.0.0.1:{http_port}', '-t', str(ROOT / 'public')], env=dict(os.environ, BITCART_STORAGE_DIR=str(Path(folder)/'storage')), stdout=log, stderr=log)
    browser = None
    try:
        browser = subprocess.Popen([CHROME, '--headless', '--disable-gpu', '--disable-extensions', '--no-first-run', '--no-default-browser-check', f'--remote-debugging-port={debug_port}', f'--user-data-dir={folder}/browser', 'about:blank'], stdout=log, stderr=log)
        for _ in range(100):
            try:
                pages = json.load(urllib.request.urlopen(f'http://127.0.0.1:{debug_port}/json/list'))
                target = next(p for p in pages if p['type'] == 'page')
                break
            except Exception:
                time.sleep(.1)
        errors = []
        with connect(target['webSocketDebuggerUrl'], max_size=10_000_000, proxy=None) as ws:
            sequence = 0
            def command(method, params={}):
                global sequence
                sequence += 1
                ws.send(json.dumps(dict(id=sequence, method=method, params=params)))
                while True:
                    message = json.loads(ws.recv(timeout=15))
                    if message.get('method') == 'Runtime.exceptionThrown': errors.append(message['params'])
                    if message.get('id') == sequence:
                        assert 'error' not in message, message
                        return message.get('result', {})
            def js(expression):
                result = command('Runtime.evaluate', dict(expression=expression, returnByValue=True, awaitPromise=True))
                assert 'exceptionDetails' not in result, result
                return result.get('result', {}).get('value')
            def wait(expression):
                for _ in range(100):
                    if js(expression): return
                    time.sleep(.05)
                raise AssertionError('Timed out: '+expression)
            def visit(path):
                command('Page.navigate', dict(url=base+path))
                wait('document.readyState === "complete" && location.pathname === '+json.dumps(path.split('?')[0]))
            def fill(selector, value):
                js(f'document.querySelector({json.dumps(selector)}).value={json.dumps(value)}')
            def click(selector): js(f'document.querySelector({json.dumps(selector)}).click()')
            def check(expression, label):
                assert js(expression), label
                print('PASS', label)
            def upload(selector):
                fixture=Path(folder)/'test-image.png'
                fixture.write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII='))
                root=command('DOM.getDocument')['root']['nodeId']
                node=command('DOM.querySelector',dict(nodeId=root,selector=selector))['nodeId']
                command('DOM.setFileInputFiles',dict(nodeId=node,files=[str(fixture)]))
            command('Runtime.enable')
            visit('/setup.php')
            fill('[name=password]', 'Browser-test-password-123!'); fill('[name=confirm]', 'Browser-test-password-123!'); click('button')
            wait('location.pathname === "/admin-login.php"')
            fill('[name=password]', 'Browser-test-password-123!'); click('button')
            wait('location.pathname === "/admin.php"')
            fill('[name=bitcoin_address]','1BoatSLRHtKNngkdXEeobR76b53LETtpyT');fill('[name=usd_per_btc]','100000');click('form[action="/admin-settings.php"] button')
            wait('location.search.includes("saved")')
            fill('[name=name]', 'Browser Goods'); fill('[name=price]', '12.50'); fill('[name=stock]', '5');upload('[name=image]')
            wait('document.getElementById("imagePreviewStatus").textContent.includes("ready")')
            click('form[action="/admin-product.php"] .form-actions button')
            wait('document.querySelector("table").textContent.includes("Browser Goods")')
            visit('/')
            fill('.product-quantity input', '2'); click('[data-add]')
            check('!document.getElementById("cartDrawer").hidden && document.getElementById("cartCount").textContent === "2"', 'Actual Add button opens cart with selected quantity')
            check('document.getElementById("cartTotal").textContent.includes("0.00025000")', 'Cart subtotal updates immediately')
            click('[data-plus]'); click('[data-minus]')
            check('document.querySelector("[data-quantity]").value === "2"', 'Cart plus and minus buttons')
            js('document.querySelector("[data-quantity]").value="4";document.querySelector("[data-quantity]").dispatchEvent(new Event("change",{bubbles:true}))')
            check('document.getElementById("cartTotal").textContent.includes("0.00050000")', 'Typed cart quantity updates total')
            click('#cartDrawer .close-drawer'); click('[data-wish]'); click('#openWishlist')
            check('!document.getElementById("wishlistDrawer").hidden && document.getElementById("wishlistCount").textContent === "1"', 'Wishlist button and drawer')
            click('[data-unwish]'); click('#wishlistDrawer .close-drawer'); click('#openCart'); click('#clearCart')
            check('document.getElementById("checkoutButton").disabled', 'Empty cart blocks checkout')
            click('#cartDrawer .close-drawer'); click('[data-add]'); click('[data-remove]')
            check('document.getElementById("cartCount").textContent === "0"', 'Remove item button')
            click('#cartDrawer .close-drawer'); click('[data-add]'); click('#checkoutButton')
            wait('location.pathname === "/checkout.php" && document.readyState === "complete"')
            check('document.getElementById("checkoutTotal").textContent.includes("0.00025000")', 'Checkout preserves cart and total')
            fill('[name=name]', 'Browser Buyer'); fill('[name=contact]', '@browser-buyer'); fill('[name=address]', '123 Test Street'); fill('[name=city]', 'Test City'); click('button[type=submit]')
            wait('location.pathname === "/payment.php"')
            wait('document.readyState === "complete"')
            check('document.body.textContent.includes("PENDING") && document.body.textContent.includes("0.00025000")', 'Delivery form creates correct pending order')
            check('JSON.parse(localStorage.getItem("bitcart_cart_v1") || "[]").length === 0', 'Successful checkout clears cart')
            check('document.querySelector("#bitcoinQr svg") !== null','Bitcoin address QR generated locally')
            check('document.getElementById("bitcoinAddress").textContent === "1BoatSLRHtKNngkdXEeobR76b53LETtpyT"','Payment receiving address displayed')
            payment_url=js('location.pathname+location.search')
            fill('[name=payer_name]','Chosen Payer');upload('[name=payment_screenshot]');click('[name=payment_sent]');click('button[type=submit]')
            wait('document.body.textContent.includes("PAYMENT REVIEW")')
            check('document.body.textContent.includes("awaiting manual review")','Screenshot submission waits for admin approval')
            visit('/admin-review.php?order=1')
            check('document.body.textContent.includes("@browser-buyer") && document.body.textContent.includes("Chosen Payer")','Admin sees customer contact and payer name')
            wait('document.querySelector(".payment-proof").complete')
            check('document.querySelector(".payment-proof").naturalWidth === 1','Admin screenshot loads from private storage')
            js('document.querySelector("[name=status]").value="paid"');click('.primary-button')
            wait('document.body.textContent.includes("Status: paid")')
            visit(payment_url)
            check('document.body.textContent.includes("manually approved")','Admin approval appears on private payment page')
            visit('/')
            js('localStorage.setItem("bitcart_cart_v1", "null")')
            visit('/')
            click('[data-add]')
            check('!document.getElementById("cartDrawer").hidden', 'Actual Add button survives malformed saved cart')
            with sqlite3.connect(Path(folder)/'storage/store.sqlite') as database:
                database.execute('UPDATE products SET stock=1,price_inr=20')
            js('window.dispatchEvent(new Event("focus"))')
            wait('document.getElementById("cartTotal").textContent.includes("0.00020000")')
            check('document.querySelector(".product-quantity input").max === "1" && document.querySelector(".product-bottom strong").textContent.includes("20.00 USD")', 'Live stock and prices refresh without reloading')
            fill('#search', 'no matching item'); js('document.getElementById("search").dispatchEvent(new Event("input"))')
            check('document.querySelector(".product-card").hidden', 'Search filters products')
            assert not errors, errors
            print('Browser flow passed with no uncaught JavaScript exceptions.')
    finally:
        if browser:
            browser.terminate(); browser.wait(timeout=10)
        server.terminate(); server.wait(timeout=10)
