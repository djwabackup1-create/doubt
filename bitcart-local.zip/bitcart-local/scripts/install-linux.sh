#!/usr/bin/env bash
# Called by host-onion.sh via sudo; installs distro packages, never remote shell code.
set -Eeuo pipefail
[[ "$EUID" == 0 ]] || { echo 'The package installer requires sudo.' >&2; exit 1; }
command -v apt-get >/dev/null || { echo 'Automatic installation supports Debian, Ubuntu and Tails only.' >&2; exit 1; }
command -v flock >/dev/null || { echo 'Install util-linux first (flock is required).' >&2; exit 1; }
exec 9>/run/lock/bitcart-package-install.lock
flock -n 9 || { echo 'Another BitCart package installation is running.' >&2; exit 1; }
packages=(python3 php-cli php-fpm php-sqlite3 php-mbstring nginx)
nginx_was_installed=0
dpkg-query -W -f='${Status}' nginx 2>/dev/null | grep -q 'install ok installed' && nginx_was_installed=1
tor_was_installed=0
dpkg-query -W -f='${Status}' tor 2>/dev/null | grep -q 'install ok installed' && tor_was_installed=1
if [[ -e /etc/amnesia/version ]] || grep -qs '^ID=tails$' /etc/os-release; then
    command -v tor >/dev/null || { echo 'Tails Tor is missing. Restore a standard Tails installation first.' >&2; exit 1; }
else
    packages+=(tor)
fi
# Prevent post-install hooks from starting a default web server on public interfaces.
# Preserve any pre-existing system policy exactly, including a symlink.
backup_dir="$(mktemp -d /run/bitcart-install.XXXXXXXX)"
policy_path=/usr/sbin/policy-rc.d
had_policy=0
if [[ -e "$policy_path" || -L "$policy_path" ]]; then
    cp -a -- "$policy_path" "$backup_dir/original-policy"
    had_policy=1
fi
restore_policy() {
    if [[ "$had_policy" == 1 ]]; then
        mv -Tf -- "$backup_dir/original-policy" "$policy_path"
    else
        rm -f -- "$policy_path"
    fi
    rm -f -- "$backup_dir/new-policy"
    rmdir -- "$backup_dir"
}
trap restore_policy EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
printf '#!/bin/sh\nexit 101\n' > "$backup_dir/new-policy"
chmod 755 "$backup_dir/new-policy"
mv -Tf -- "$backup_dir/new-policy" "$policy_path"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install --yes --no-install-recommends "${packages[@]}"
if command -v systemctl >/dev/null; then
    # Newly installed default services must not bind public ports after a reboot.
    # Do not change an existing nginx or Tor deployment.
    if [[ "$nginx_was_installed" == 0 ]]; then systemctl disable nginx.service; fi
    if [[ "$tor_was_installed" == 0 ]]; then systemctl disable tor.service tor@default.service || true; fi
fi
echo 'Packages installed. BitCart starts its own localhost-only server; default system web services were not started by this installation.'
