"""Own a Tor v3 service for the lifetime of stdin; never rewrite system torrc.

On Tails, sudo permits access to the existing Tor control socket. The process
drops back to SUDO_UID before reading/writing any BitCart storage or onion keys.
"""
import argparse
import ast
import base64
import os
from pathlib import Path
import re
import select
import signal
import socket
import sys


class ControlError(RuntimeError):
    pass


class Controller:
    def __init__(self, endpoint):
        self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.socket.settimeout(10)
        self.socket.connect(str(endpoint))
        self.reader = self.socket.makefile('rb')

    def command(self, value):
        if '\r' in value or '\n' in value:
            raise ControlError('Invalid control command')
        self.socket.sendall(value.encode('ascii') + b'\r\n')
        lines = []
        for _ in range(100):
            raw = self.reader.readline(65537)
            if not raw or len(raw) > 65536:
                raise ControlError('Tor control connection closed or invalid reply')
            line = raw.decode('ascii').rstrip('\r\n')
            if not re.match(r'^\d{3}[- ]', line):
                raise ControlError('Unsupported Tor control reply')
            if line[:3] != '250':
                # Do not include the submitted command: ADD_ONION contains a secret key.
                raise ControlError('Tor rejected the request: ' + line[:250])
            lines.append(line[4:])
            if line[3] == ' ':
                return lines
        raise ControlError('Tor control reply is too long')

    def authenticate(self):
        info = self.command('PROTOCOLINFO 1')
        auth = next((line for line in info if line.startswith('AUTH ')), '')
        methods = re.search(r'METHODS=([^ ]+)', auth)
        cookie = re.search(r'COOKIEFILE=("(?:[^"\\]|\\.)*")', auth)
        if not methods or 'COOKIE' not in methods[1].split(',') or not cookie:
            raise ControlError('A local Tor control socket with COOKIE authentication is required')
        cookie_file = Path(ast.literal_eval(cookie[1]))
        if not cookie_file.is_absolute():
            raise ControlError('Tor returned a relative cookie path')
        token = cookie_file.read_bytes()
        if len(token) != 32:
            raise ControlError('Unexpected Tor authentication cookie length')
        self.command('AUTHENTICATE ' + token.hex())

    def close(self):
        self.reader.close()
        self.socket.close()


def write_private(path, value):
    temporary = path.with_name(path.name + '.new-' + str(os.getpid()))
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='ascii') as output:
            output.write(value)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def valid_key(key):
    if not re.fullmatch(r'ED25519-V3:[A-Za-z0-9+/=]+', key):
        return False
    try:
        return len(base64.b64decode(key.split(':', 1)[1], validate=True)) == 64
    except ValueError:
        return False


def register(controller, directory, port):
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    directory.chmod(0o700)
    key_path = directory / 'private_key'
    hostname_path = directory / 'hostname'
    if key_path.is_symlink() or hostname_path.is_symlink():
        raise ControlError('Onion identity files must not be symlinks')
    if key_path.exists():
        key = key_path.read_text(encoding='ascii').strip()
        if not valid_key(key):
            raise ControlError('Saved onion key is invalid. Restore it from backup; it will not be replaced.')
        key_path.chmod(0o600)
    else:
        if hostname_path.exists():
            raise ControlError('Onion hostname exists but its key is missing. Restore the key to keep that address.')
        key = 'NEW:ED25519-V3'
    lines = controller.command(f'ADD_ONION {key} Port=80,127.0.0.1:{port}')
    values = dict(line.split('=', 1) for line in lines if '=' in line)
    service_id = values.get('ServiceID', '')
    if not re.fullmatch(r'[a-z2-7]{56}', service_id):
        raise ControlError('Tor did not return a valid v3 onion service identifier')
    if key == 'NEW:ED25519-V3':
        secret = values.get('PrivateKey', '')
        if not valid_key(secret):
            raise ControlError('Tor did not return a persistable v3 onion key')
        write_private(key_path, secret + '\n')
    hostname = service_id + '.onion'
    if hostname_path.exists() and hostname_path.read_text().strip() != hostname:
        raise ControlError('Saved onion hostname does not match the key; refusing to change the address')
    write_private(hostname_path, hostname + '\n')
    return hostname


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--socket', type=Path)
    parser.add_argument('--storage', type=Path, required=True)
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        raise ControlError('The local HTTP port must be between 1024 and 65535')
    endpoints = [args.socket] if args.socket else [Path('/run/tor/control'), Path('/run/tor/control.sock'), Path('/run/tor-instances/default/control')]
    controller = None
    for endpoint in endpoints:
        try:
            candidate = Controller(endpoint)
            try:
                candidate.authenticate()
            except Exception:
                candidate.close()
                raise
            controller = candidate
            break
        except (OSError, ControlError):
            continue
    if controller is None:
        raise ControlError('Cannot authenticate to the local Tor control socket. On Tails, connect to Tor and set an administration password at startup. This launcher does not disable onion-grater or change Tor settings.')
    try:
        if os.geteuid() == 0:
            uid = int(os.environ.get('SUDO_UID', '0'))
            gid = int(os.environ.get('SUDO_GID', '0'))
            if uid <= 0 or gid <= 0:
                raise ControlError('Run through sudo as a normal user, not from a root login')
            os.setgroups([])
            os.setgid(gid)
            os.setuid(uid)
        # All store paths and identity keys are opened only after dropping root.
        hostname = register(controller, args.storage.resolve() / 'onion', args.port)
        print('ONION_URL=http://' + hostname, flush=True)
        # No Detach flag: closing this connection removes only this onion service.
        while True:
            readable, _, _ = select.select([sys.stdin], [], [], 10)
            if readable and not sys.stdin.buffer.read(1):
                return
            controller.command('GETINFO status/circuit-established')
    finally:
        controller.close()


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        main()
    except (OSError, ValueError, ControlError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
