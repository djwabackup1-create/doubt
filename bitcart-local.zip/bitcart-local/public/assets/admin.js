(() => {
 const currency=document.getElementById('priceCurrency'), price=document.getElementById('productPrice');
 if(currency&&price){const update=()=>{price.min=price.step=currency.value==='BTC'?'0.00000001':'0.01';};currency.addEventListener('change',update);update();}
 const input=document.getElementById('imageUpload'), panel=document.getElementById('imagePreviewPanel'), preview=document.getElementById('imagePreview'), status=document.getElementById('imagePreviewStatus');
 if(!input)return;
 let objectUrl;
 input.addEventListener('change',()=>{
   if(objectUrl)URL.revokeObjectURL(objectUrl);
   const file=input.files[0];input.setCustomValidity('');if(!file)return;
   panel.hidden=false;preview.hidden=true;
   if(file.size>10*1024*1024){input.setCustomValidity('Choose an image no larger than 10 MB.');status.textContent='Image is too large.';return;}
   objectUrl=URL.createObjectURL(file);preview.onload=()=>{preview.hidden=false;status.textContent='Image ready to upload.';};
   preview.onerror=()=>{status.textContent='This browser cannot preview the image. The server will check its format when saving.';};preview.src=objectUrl;
 });
})();
