(() => {
 const page=document.querySelector('[data-order-status]');
 if(page) {
   let checking=false;
   setInterval(async()=>{
     if(checking||document.hidden)return;
     checking=true;
     try{const response=await fetch(page.dataset.statusUrl,{cache:'no-store'});if(response.ok){const data=await response.json();if(data.status!==page.dataset.orderStatus)location.reload();}}catch{}finally{checking=false;}
   },15000);
 }
 const qr=document.getElementById('bitcoinQr');if(!qr)return;
 const address=qr.dataset.address;
 try { const code=qrcodegen.QrCode.encodeText(address,qrcodegen.QrCode.Ecc.MEDIUM), ns='http://www.w3.org/2000/svg';
   const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox',`0 0 ${code.size+8} ${code.size+8}`);svg.setAttribute('role','img');svg.setAttribute('aria-label','Bitcoin address QR code');svg.style.background='white';svg.style.width='240px';svg.style.maxWidth='100%';
   let path='';for(let y=0;y<code.size;y++)for(let x=0;x<code.size;x++)if(code.getModule(x,y))path+=`M${x+4},${y+4}h1v1h-1z`;
   const modules=document.createElementNS(ns,'path');modules.setAttribute('d',path);modules.setAttribute('fill','black');svg.appendChild(modules);qr.appendChild(svg);
 } catch { qr.textContent='QR unavailable. Copy the Bitcoin address below.'; }
 document.getElementById('copyAddress').addEventListener('click',async()=>{
   const status=document.getElementById('copyStatus');
   try{await navigator.clipboard.writeText(address);status.textContent='Bitcoin address copied.';}catch{const range=document.createRange();range.selectNodeContents(document.getElementById('bitcoinAddress'));const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);status.textContent='Address selected. Copy it using your browser.';}
 });
})();
