(() => {
const store=window.BitCart; let cart=store.write(store.read()); let submitting=false;
const products=window.BITCART_PRODUCTS||[];const money=n=>Number(n).toFixed(8)+' BTC';
const list=document.getElementById('checkoutItems');const total=cart.reduce((s,x)=>s+(products.find(p=>p.id===x.id)?.price||0)*x.qty,0);
list.innerHTML=cart.map(x=>{const p=products.find(p=>p.id===x.id);return p?`<div class="summary-item"><span>${esc(p.name)} × ${x.qty}</span><strong>${money(p.price*x.qty)}</strong></div>`:''}).join('')||'<p class="muted">Your cart is empty. <a href="/">Return to shop</a>.</p>';
document.getElementById('checkoutTotal').textContent=money(total);
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const form=document.getElementById('checkoutForm'),msg=document.getElementById('checkoutMessage');
form.addEventListener('submit',async e=>{e.preventDefault();if(submitting)return;if(!cart.length){msg.hidden=false;msg.textContent='Your cart is empty.';return}if(!form.reportValidity())return;submitting=true;
const btn=form.querySelector('button[type=submit]');btn.disabled=true;btn.textContent='Creating order…';msg.hidden=true;
const f=new FormData(form);const body={csrf:f.get('csrf'),name:f.get('name'),contact:f.get('contact'),address:f.get('address'),city:f.get('city'),note:f.get('note'),items:cart,expected_total:Math.round(total*100000000)/100000000};
try{const r=await fetch('/api/create-order.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});let data;try{data=await r.json()}catch{throw new Error(r.status===419?'Your session expired. Refresh this page and try again.':'The server could not process checkout. Please try again.')}if(!r.ok||!data.ok)throw new Error(data.error||'Could not create order.');store.clear();location.href=data.url}
catch(err){msg.hidden=false;msg.textContent=err.message;btn.disabled=false;btn.textContent='Create Bitcoin order ↗';submitting=false}
});
})();
