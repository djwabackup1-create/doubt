<?php
require_once __DIR__ . '/../src/bootstrap.php';
require_admin_post();
$id=(int)($_POST['id']??0); $status=(string)($_POST['status']??'');
$allowed=['pending','payment_review','paid','processing','shipped','cancelled'];
if(!in_array($status,$allowed,true)){http_response_code(400);exit('Invalid status');}
try { update_order_status($id,$status); }
catch (RuntimeException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8')); }
header('Location: /admin-review.php?order='.$id); exit;
