<?php
require_once __DIR__.'/../src/bootstrap.php';
header('Cache-Control: no-store'); header('Referrer-Policy: no-referrer');
$orderId=(int)($_GET['order']??0); $ref=(string)($_GET['ref']??'');
$s=db()->prepare('SELECT * FROM orders WHERE id=? AND public_ref=?'); $s->execute([$orderId,$ref]); $order=$s->fetch();
if(!$order) { http_response_code(404); exit('Order not found. Check the private order link.'); }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    try {
        if(!in_array($order['status'],['pending','payment_review'],true)||$order['total_sats']===null) throw new RuntimeException('This order is not accepting payment screenshots.');
        $payer=trim((string)($_POST['payer_name']??''));
        if($payer===''||mb_strlen($payer)>120) throw new RuntimeException('Enter your name or the name you want to be called.');
        if(!isset($_POST['payment_sent'])) throw new RuntimeException('Confirm that you have sent the Bitcoin payment.');
        $proof=save_image_upload('payment_screenshot','proofs',true);
        $s=db()->prepare("UPDATE orders SET proof_file=?,payer_name=?,status='payment_review',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status IN ('pending','payment_review')"); $s->execute([$proof,$payer,$orderId]);
        if($s->rowCount()!==1) { @unlink(storage_dir().'/uploads/proofs/'.$proof); throw new RuntimeException('The order status changed. Refresh to check it.'); }
        if($order['proof_file']) @unlink(storage_dir().'/uploads/proofs/'.$order['proof_file']);
        header('Location: /payment.php?order='.$orderId.'&ref='.rawurlencode($ref).'&submitted=1'); exit;
    } catch(RuntimeException $exception) { http_response_code(400); $error=$exception->getMessage(); }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>Bitcoin payment — BitCart</title><link rel="stylesheet" href="/assets/style.css?v=3"></head><body><header class="topbar"><a class="brand" href="/">BIT<span>CART</span><small>ORDER PAYMENT</small></a></header><main class="payment-page" data-order-status="<?= e($order['status']) ?>" data-status-url="/api/order-status.php?order=<?= $orderId ?>&amp;ref=<?= e($ref) ?>"><div class="eyebrow">ORDER #<?= $orderId ?></div><h1>Bitcoin payment</h1><div class="status-pill"><?= e(strtoupper(str_replace('_',' ',$order['status']))) ?></div>
<?php if($order['total_sats']!==null): ?>
<p>Send exactly <strong id="paymentAmount"><?= e(btc((int)$order['total_sats'])) ?></strong> on the Bitcoin network.</p>
<p>Paying as: <strong><?= e($order['payer_name']?:$order['customer_name']) ?></strong></p>
<?php if(in_array($order['status'],['pending','payment_review'],true)): ?>
<p class="muted">1. Send Bitcoin to the address below. 2. Attach your payment screenshot and name. 3. Submit for manual approval. If you already paid, do not pay again.</p>
<div id="bitcoinQr" data-address="<?= e($order['payment_address']) ?>" aria-label="Bitcoin receiving address QR code"></div>
<p id="bitcoinAddress" class="wallet-address"><?= e($order['payment_address']) ?></p><button id="copyAddress" class="secondary-button" type="button">Copy Bitcoin address</button><p id="copyStatus" class="muted small" role="status"></p>
<?php if($order['status']==='payment_review'): ?><p class="notice" role="status">Screenshot submitted. Your payment is awaiting manual review. The admin can contact you using the details you provided at checkout. You can replace your screenshot below if needed.</p><?php endif; ?>
<?php if($error): ?><p class="notice error" role="alert"><?= e($error) ?></p><?php endif; ?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><label>Your name / what should we call you?<input name="payer_name" required maxlength="120" value="<?= e($order['payer_name']?:$order['customer_name']) ?>"></label><label>Payment screenshot<input name="payment_screenshot" type="file" accept="image/*" required><small class="muted">Upload a raster image up to 10 MB. Include only the payment details needed for review.</small></label><label class="check-label"><input type="checkbox" name="payment_sent" required value="1">I have sent the exact BTC amount to the address above.</label><button class="primary-button" type="submit">Submit payment for review</button></form>
<?php elseif($order['status']==='cancelled'): ?><p class="notice">This order was cancelled. Do not send a payment. If you already paid, contact the store.</p>
<?php else: ?><p class="notice">Your payment has been manually approved. Order status: <?= e($order['status']) ?>.</p><?php endif; ?>
<?php else: ?><p class="notice">This order uses the previous payment system. Contact the store before paying.</p><?php endif; ?>
<p class="muted">Keep this private order link to check approval and order status.</p><button class="secondary-button" onclick="location.reload()">Refresh status</button></main><script src="/assets/vendor/qrcodegen.js"></script><script src="/assets/payment.js?v=3"></script></body></html>
