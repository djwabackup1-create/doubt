<?php
http_response_code(410);
exit('Automatic payments are disabled. Orders require manual admin approval.');
