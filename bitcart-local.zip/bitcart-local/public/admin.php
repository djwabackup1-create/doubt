<?php
require_once __DIR__.'/../src/bootstrap.php';
if(!admin_logged_in()) { header('Location: /admin-login.php'); exit; }
$products=db()->query('SELECT * FROM products ORDER BY id DESC')->fetchAll();
$orders=db()->query('SELECT * FROM orders ORDER BY id DESC LIMIT 100')->fetchAll();
$editing=null; if(isset($_GET['edit'])) { $s=db()->prepare('SELECT * FROM products WHERE id=?'); $s->execute([(int)$_GET['edit']]); $editing=$s->fetch(); }
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin — BitCart</title><link rel="stylesheet" href="/assets/style.css?v=3"></head><body>
<header class="topbar"><a class="brand" href="/">BIT<span>CART</span><small>ADMIN STUDIO</small></a><form method="post" action="/admin-logout.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><button class="text-button">Log out</button></form></header>
<main class="admin-main"><div class="admin-title"><h1>Store management</h1><span class="status-pill">ADMIN</span></div>
<section class="admin-panel"><h2>Bitcoin payment settings</h2><p class="muted">Enter your receiving address and the USD value of 1 BTC. Prices default to USD; customers pay the exact BTC total shown on their order. Update the rate manually when needed.</p>
<?php if(isset($_GET['settings'])): ?><p role="status">Payment settings saved.</p><?php endif; ?>
<form method="post" action="/admin-settings.php" class="product-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<label class="full-field">Bitcoin receiving address<input name="bitcoin_address" required value="<?= e(setting('bitcoin_address')) ?>" placeholder="Your Bitcoin mainnet receiving address" autocomplete="off"></label>
<label>USD value of 1 BTC<input type="number" name="usd_per_btc" min="0.01" step="0.01" required value="<?= e(setting('usd_per_btc')) ?>"></label>
<div class="full-field form-actions"><button class="primary-button">Save payment settings</button></div></form></section>
<section class="admin-panel"><h2><?= $editing?'Edit product':'Add a product' ?></h2>
<?php if($editing && $editing['price_currency']==='INR'): ?><p class="notice">This product has a legacy price and is hidden from the shop. Enter a new USD or BTC price before publishing; no automatic currency conversion has been applied.</p><?php endif; ?>
<form method="post" action="/admin-product.php" enctype="multipart/form-data" class="product-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)($editing['id']??0) ?>">
<label>Product name<input name="name" required maxlength="160" value="<?= e($editing['name']??'') ?>"></label>
<label>Price<input id="productPrice" name="price" type="number" min="0.00000001" step="0.00000001" required value="<?= e($editing && $editing['price_currency']!=='INR'?$editing['price_inr']:'') ?>"></label>
<label>Price currency<select id="priceCurrency" name="currency"><option value="USD" <?= ($editing['price_currency']??'USD')==='USD'?'selected':'' ?>>USD</option><option value="BTC" <?= ($editing['price_currency']??'')==='BTC'?'selected':'' ?>>BTC</option></select></label>
<label>Stock quantity<input name="stock" type="number" min="0" max="100000" required value="<?= e($editing['stock']??0) ?>"></label>
<label>Upload product image<input id="imageUpload" name="image" type="file" accept="image/*"><small class="muted">Up to 10 MB. JPG, PNG, GIF, WebP, AVIF, BMP, ICO and TIFF. Unsupported images must be exported to PNG or JPG.</small></label>
<label class="check-label"><input type="checkbox" name="remove_image">Remove current image</label>
<div class="full-field" id="imagePreviewPanel" <?= empty($editing['image_url'])||!str_starts_with($editing['image_url'],'/media.php?image=')?'hidden':'' ?>><img id="imagePreview" src="<?= e(!empty($editing['image_url'])&&str_starts_with($editing['image_url'],'/media.php?image=')?$editing['image_url']:'') ?>" alt="Product image preview" style="max-width:100%;max-height:240px;object-fit:contain"><p id="imagePreviewStatus" class="muted small" role="status"></p></div>
<label class="full-field">Description<textarea name="description" maxlength="3000" rows="3"><?= e($editing['description']??'') ?></textarea></label>
<label class="check-label"><input type="checkbox" name="active" value="1" <?= !isset($editing['active'])||$editing['active']?'checked':'' ?>>Published on storefront</label>
<div class="full-field form-actions"><button class="primary-button"><?= $editing?'Save changes':'Add product' ?></button><?php if($editing): ?><a href="/admin.php">Cancel</a><?php endif; ?></div></form></section>
<section class="admin-panel"><h2>Products</h2><div class="table-wrap"><table><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach($products as $p): ?><tr><td><?= e($p['name']) ?></td><td><?= $p['price_currency']==='INR'?'Needs repricing':e(price_label($p)) ?></td><td><?= (int)$p['stock'] ?></td><td><?= $p['active']?'Published':'Hidden' ?></td><td><a href="/admin.php?edit=<?= (int)$p['id'] ?>">Edit</a> <form class="inline-form" method="post" action="/admin-product.php" onsubmit="return confirm('Delete this product?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button name="delete" value="1" class="danger-link">Delete</button></form></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<section class="admin-panel"><h2>Recent orders</h2><p class="muted">Open an order to view contact details and the payment screenshot. Verify receipt in your own Bitcoin wallet before approving payment.</p><div class="table-wrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Created</th><th>Action</th></tr></thead><tbody>
<?php foreach($orders as $o): ?><tr><td>#<?= (int)$o['id'] ?></td><td><?= e($o['customer_name']) ?></td><td><?= $o['total_sats']!==null?e(btc((int)$o['total_sats'])):'Legacy order' ?></td><td><?= e($o['status']) ?></td><td><?= e($o['created_at']) ?></td><td><a class="small-button" href="/admin-review.php?order=<?= (int)$o['id'] ?>">Review order</a></td></tr><?php endforeach; ?>
</tbody></table></div></section></main><script src="/assets/admin.js?v=3"></script></body></html>
