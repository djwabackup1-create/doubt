<?php
require_once __DIR__.'/../src/bootstrap.php';
require_admin_post();
$id=(int)($_POST['id']??0);
if(isset($_POST['delete'])) { $s=db()->prepare('DELETE FROM products WHERE id=?'); $s->execute([$id]); header('Location: /admin.php'); exit; }
$name=trim((string)($_POST['name']??'')); $description=trim((string)($_POST['description']??''));
$price=filter_var($_POST['price']??null,FILTER_VALIDATE_FLOAT); $stock=filter_var($_POST['stock']??null,FILTER_VALIDATE_INT);
$currency=(string)($_POST['currency']??'USD'); $active=isset($_POST['active'])?1:0;
try {
    if($name===''||mb_strlen($name)>160||mb_strlen($description)>3000||$price===false||!is_finite($price)||$price<=0||$price>1000000000||$stock===false||$stock<0||$stock>100000||!in_array($currency,['BTC','USD'],true)) throw new RuntimeException('Invalid product details.');
    if($currency==='BTC'&&($price<0.00000001||$price>21000000||abs($price*100000000-round($price*100000000))>0.001)) throw new RuntimeException('BTC prices need at most eight decimal places.');
    if($currency==='USD'&&($price<0.01||abs($price*100-round($price*100))>0.001)) throw new RuntimeException('USD prices need at most two decimal places.');
    $image='';
    if($id>0) { $s=db()->prepare('SELECT image_url FROM products WHERE id=?'); $s->execute([$id]); $old=$s->fetchColumn(); if($old===false) throw new RuntimeException('Product not found.'); if(str_starts_with($old,'/media.php?image=')) $image=$old; }
    if(isset($_POST['remove_image'])) $image='';
    $uploaded=save_image_upload('image','products'); if($uploaded) $image='/media.php?image='.$uploaded;
    if($id>0) { $s=db()->prepare('UPDATE products SET name=?,description=?,price_inr=?,stock=?,image_url=?,active=?,price_currency=?,updated_at=CURRENT_TIMESTAMP WHERE id=?'); $s->execute([$name,$description,$price,$stock,$image,$active,$currency,$id]); }
    else { $s=db()->prepare('INSERT INTO products(name,description,price_inr,stock,image_url,active,price_currency) VALUES(?,?,?,?,?,?,?)'); $s->execute([$name,$description,$price,$stock,$image,$active,$currency]); }
    header('Location: /admin.php'); exit;
} catch(RuntimeException $error) { http_response_code(400); exit(e($error->getMessage()).' Go back and check the fields.'); }
