<?php
require_once __DIR__ . '/../src/bootstrap.php';
if (admin_logged_in()) { header('Location: /admin.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $config = admin_config();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!login_allowed($ip)) { http_response_code(429); $error = 'Too many attempts. Wait 15 minutes.'; }
    elseif ($config && password_verify((string)($_POST['password'] ?? ''), $config['password_hash'])) {
        session_regenerate_id(true); $_SESSION['admin'] = true; clear_login_attempts($ip); header('Location: /admin.php'); exit;
    } else { record_login_attempt($ip); $error = 'Incorrect password.'; }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin access — BitCart</title><link rel="stylesheet" href="/assets/style.css?v=2"></head><body><header class="topbar"><a class="brand" href="/">BIT<span>CART</span><small>PRIVATE ACCESS</small></a></header><main class="login-page"><div class="eyebrow">RESTRICTED AREA</div><h1>Admin access.</h1><p class="muted">Authorised company personnel only.</p><?php if($error): ?><div class="notice error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><label>Admin password<input type="password" name="password" required autocomplete="current-password" autofocus></label><button class="primary-button">Unlock admin ↗</button></form></main></body></html>
