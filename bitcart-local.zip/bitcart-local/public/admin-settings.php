<?php
require_once __DIR__.'/../src/bootstrap.php';
require_admin_post();
$address=trim((string)($_POST['bitcoin_address']??''));
$rate=filter_var($_POST['usd_per_btc']??null,FILTER_VALIDATE_FLOAT);
if (!valid_bitcoin_address($address)||$rate===false||!is_finite($rate)||$rate<=0||$rate>1000000000) { http_response_code(400); exit('Enter a valid Bitcoin mainnet receiving address and a positive USD price for 1 BTC.'); }
$pdo=db(); $pdo->beginTransaction();
foreach(['bitcoin_address'=>$address,'usd_per_btc'=>(string)$rate] as $key=>$value) $pdo->prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)')->execute([$key,$value]);
$pdo->commit(); header('Location: /admin.php?settings=saved'); exit;
