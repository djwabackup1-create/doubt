<?php
require_once __DIR__ . '/../src/bootstrap.php';
if (file_exists(storage_dir() . '/config.php')) { http_response_code(403); exit('Setup is already complete. Delete this file.'); }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf(); $pw=(string)($_POST['password']??''); $confirm=(string)($_POST['confirm']??'');
  if(strlen($pw)<11) $error='Use at least 11 characters.';
  elseif(!hash_equals($pw,$confirm)) $error='Passwords do not match.';
  else {
    $content="<?php\nreturn ['password_hash' => ".var_export(password_hash($pw,PASSWORD_DEFAULT),true)."];\n";
    $configPath=storage_dir().'/config.php';
    if(file_put_contents($configPath,$content,LOCK_EX)===false) throw new RuntimeException('Could not save the admin configuration.');
    if(!chmod($configPath,0600)) throw new RuntimeException('Could not restrict permissions on the admin configuration.');
    header('Location: /admin-login.php?setup=complete'); exit;
  }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Initial setup — BitCart</title><link rel="stylesheet" href="/assets/style.css?v=2"></head><body><main class="login-page"><div class="eyebrow">ONE-TIME SETUP</div><h1>Secure your admin.</h1><p class="muted">Enter your chosen admin password twice. Use at least 11 characters.</p><?php if($error): ?><div class="notice error"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><label>Admin password<input type="password" name="password" required minlength="11" autocomplete="new-password"></label><label>Confirm password<input type="password" name="confirm" required minlength="11" autocomplete="new-password"></label><button class="primary-button">Create admin password</button></form></main></body></html>
