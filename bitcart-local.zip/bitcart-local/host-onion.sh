#!/usr/bin/env bash
# Run from a terminal: bash host-onion.sh
set -Eeuo pipefail
export PATH="$PATH:/usr/sbin:/sbin"
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
project_dir="$(pwd -P)"
if [[ "${1:-}" == '--help' ]]; then
    cat <<'HELP'
BitCart onion hosting (Tails / Debian / Ubuntu)
  bash host-onion.sh             Install missing packages and start hosting
  bash host-onion.sh --check     Check prerequisites without installing or publishing

On Tails: connect to Tor first, unlock Persistent Storage, and keep the
project in ~/Persistent. Set an administration password at the Welcome Screen.
The onion address is printed after Tor creates the service. Ctrl+C stops it.
BITCART_STORAGE_DIR overrides private storage; BITCART_PORT defaults to 8080.
HELP
    exit 0
fi
if [[ "$(uname -s)" != Linux ]]; then
    echo 'Run this file on Linux, not Windows.' >&2; exit 1
fi
if [[ "$EUID" == 0 ]]; then
    echo 'Run as your normal desktop user, without sudo. The launcher requests sudo only where needed.' >&2; exit 1
fi
if [[ "${1:-}" != '--check' ]]; then
    missing=0
    for executable in python3 php nginx tor; do
        command -v "$executable" >/dev/null 2>&1 || missing=1
    done
    compgen -G '/usr/sbin/php-fpm[0-9]*' >/dev/null || missing=1
    if command -v php >/dev/null 2>&1; then
        php -r 'exit(PHP_VERSION_ID>=80100 && extension_loaded("pdo_sqlite") && extension_loaded("mbstring") ? 0 : 1);' || missing=1
    fi
    if [[ "$missing" == 1 ]]; then
        echo 'Installing PHP, SQLite support, nginx and Tor from your configured Debian/Ubuntu repositories.'
        echo 'On Tails this requires the administration password set at the Welcome Screen.'
        sudo bash "$project_dir/scripts/install-linux.sh"
    fi
fi
command -v python3 >/dev/null || { echo 'Python 3 is missing. Start without --check to install dependencies.' >&2; exit 1; }
exec python3 "$project_dir/scripts/host_onion.py" "$@"
