<?php
// Legacy file: BTCPay integration has been replaced by manual Bitcoin payments.
// Set your receiving address and USD/BTC rate in Admin → Bitcoin payment settings.
// This file is not loaded by the application.
return [];
