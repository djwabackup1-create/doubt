# Manual Tails setup and onion hosting

This starts PHP, nginx and the onion controller separately, without the automatic recovery loop. Stop at the first failed command and read its error. Actual Tails compatibility still needs verification on your machine.

Customers must sign up or sign in before browsing or checking out. Signup requires only a chosen username and password, with no verification. Contact details are requested only when placing an order.

## 1. Start Tails

At the Welcome Screen, set an Administration Password and unlock Persistent Storage. Start Tails, connect to Tor, and wait for a successful connection.

Copy the current project into `~/Persistent/bitcart-local`. Include the updated `scripts/` folder. Preserve your existing `storage/`: it contains your admin password, products, orders, uploads and any saved onion identity. Do not replace it with a fresh empty directory.

Open a terminal and keep using the **same terminal** for all commands below. Replace the folder path if you named it differently.

```sh
cd "$HOME/Persistent/bitcart-local"
export PATH="$PATH:/usr/sbin:/sbin"
sh host-onion.sh --stop
```

If the last command reports that the store is already stopped, continue.

## 2. Install requirements

```sh
sudo bash scripts/install-linux.sh
```

This uses the configured Debian repositories and suppresses package hooks that would otherwise start a default public web server. Tails' existing Tor is retained. If sudo is unavailable, restart Tails and set the Administration Password at the Welcome Screen.

Verify PHP:

```sh
php -r 'echo "PHP ",PHP_VERSION,"\n"; foreach (["pdo_sqlite","mbstring","session"] as $extension) { echo $extension,": ",extension_loaded($extension)?"OK":"MISSING","\n"; }'
```

All three extensions must say `OK`.

## 3. Prepare private storage and server configuration

```sh
umask 077
export BITCART_STORAGE_DIR="$PWD/storage"
mkdir -p "$BITCART_STORAGE_DIR"
chmod 700 "$BITCART_STORAGE_DIR"
export BITCART_RUNTIME_DIR="$(mktemp -d /tmp/bitcart-manual.XXXXXXXX)"
```

Run this entire Python command. It retains an existing admin password or prompts you to create one before publishing. It also checks existing data and backs up a healthy database before migration.

```sh
python3 -c '
import os, sys, pwd, grp, subprocess
from pathlib import Path
sys.path.insert(0, "scripts")
import host_onion as host
root = Path.cwd()
store = host.storage_location(root, os.environ["BITCART_STORAGE_DIR"], True, Path.home())
runtime = Path(os.environ["BITCART_RUNTIME_DIR"])
php, fpm, nginx, tor = host.find_tools()
host.check_persistent_state(store, backup=True)
host.ensure_admin(php, store)
subprocess.run([php, "-r", "require $argv[1];", str(root / "src/bootstrap.php")], check=True)
for name in ("uploads", "sessions", "client-body", "fastcgi-temp", "proxy-temp", "scgi-temp", "uwsgi-temp"):
    (runtime / name).mkdir(mode=0o700)
(runtime / "php-fpm.conf").write_text(host.fpm_config(store, runtime, pwd.getpwuid(os.getuid()).pw_name, grp.getgrgid(os.getgid()).gr_name))
(runtime / "nginx.conf").write_text(host.nginx_config(root, runtime, 8080))
print("Configuration ready:", runtime)
'
```

Do not continue if this reports damaged store data or a missing/damaged existing onion key. Restore the affected file from your own backup; do not delete it to bypass the check.

## 4. Validate and start PHP and nginx

```sh
FPM_BIN="/usr/sbin/php-fpm$(php -r 'echo PHP_MAJOR_VERSION,".",PHP_MINOR_VERSION;')"
"$FPM_BIN" -t -y "$BITCART_RUNTIME_DIR/php-fpm.conf"
nginx -t -p "$BITCART_RUNTIME_DIR/" -c "$BITCART_RUNTIME_DIR/nginx.conf"
```

Both checks must succeed. Start them as your normal user, **without sudo**:

```sh
"$FPM_BIN" -F -y "$BITCART_RUNTIME_DIR/php-fpm.conf" >"$BITCART_RUNTIME_DIR/php-start.log" 2>&1 &
PHP_PID=$!
nginx -p "$BITCART_RUNTIME_DIR/" -c "$BITCART_RUNTIME_DIR/nginx.conf" >"$BITCART_RUNTIME_DIR/nginx-start.log" 2>&1 &
NGINX_PID=$!
```

Check the website through its private Unix socket, avoiding Tails' TCP loopback restrictions:

```sh
python3 -c 'import os,sys; from pathlib import Path; sys.path.insert(0,"scripts"); import host_onion as h; h.wait_http(8080,[],timeout=20,unix_socket=Path(os.environ["BITCART_RUNTIME_DIR"])/"http.sock"); print("Local website is working.")'
```

If it fails, inspect these local logs **before** proceeding:

```sh
tail -n 30 "$BITCART_RUNTIME_DIR/php-start.log"
tail -n 30 "$BITCART_RUNTIME_DIR/nginx-start.log"
tail -n 30 "$BITCART_RUNTIME_DIR/nginx-error.log"
tail -n 30 "$BITCART_RUNTIME_DIR/php-errors.log"
```

A log may not exist if that component has not produced errors.

## 5. Create the onion service

With Tails connected to Tor and the local website working, run:

```sh
sudo python3 -u scripts/tor_service.py --storage "$BITCART_STORAGE_DIR" --port 8080
```

This uses Tails' existing Tor, trying control sockets and then cookie-authenticated `127.0.0.1:9052`. It drops root before saving store keys. It does not modify the firewall, disable onion-grater, expose the control port, or make Tor's cookie readable to other users.

Success prints:

```text
ONION_URL=http://<your-56-character-address>.onion
```

Open that actual URL in Tor Browser. Descriptor publication can take a few minutes. **Keep this command running:** the onion service belongs to its open control connection. The saved identity is in `storage/onion/private_key`; the address is also in `storage/onion/hostname`.

If authentication fails, copy the endpoint/error lines it prints. Do not try to fix it by disabling Tails' firewall or changing cookie permissions. No example onion address in documentation is your real address.

## 6. Configure the store

Open your real onion URL with `/admin.php` appended, log in, and set:

- Your own Bitcoin mainnet receiving address.
- The USD value of 1 BTC used for your manual conversion rate.
- USD or BTC product prices and uploaded product images.

Customers pay the fixed BTC amount shown on their order, submit a screenshot and chosen name, and wait for your manual approval. Check your receiving wallet before approving. BTCPay Server and Bitcoin Core are not required for this payment flow.

## 7. Stop hosting

In the terminal running the onion controller, press **Ctrl+C**. Then, in the same terminal:

```sh
kill "$NGINX_PID" "$PHP_PID"
wait "$NGINX_PID" "$PHP_PID"
```

A message that a process has already exited is harmless. Leave `storage/` and the onion identity intact. Manually started services are not managed by `host-onion.sh --stop` and do not have automatic recovery. A later manual start uses a new temporary runtime directory and reuses your saved onion key.

Tails must remain awake and running to host the site. Keep private storage backed up.

Sources: [Tails additional software](https://tails.net/doc/persistent_storage/additional_software/index.en.html), [Tor control protocol and service lifetime](https://spec.torproject.org/control-spec/commands.html#add_onion).
