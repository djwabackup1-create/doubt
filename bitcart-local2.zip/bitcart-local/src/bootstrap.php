<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode','1');
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax','path'=>'/']);
    session_start();
}
function db(): PDO {
    static $pdo=null; if($pdo instanceof PDO) return $pdo;
    $dir=storage_dir();
    $pdo=new PDO('sqlite:'.$dir.'/store.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',price_inr REAL NOT NULL CHECK(price_inr>0),stock INTEGER NOT NULL DEFAULT 0,image_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,public_ref TEXT NOT NULL UNIQUE,customer_name TEXT NOT NULL,customer_email TEXT NOT NULL,delivery_address TEXT NOT NULL,city TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',total_inr REAL NOT NULL,status TEXT NOT NULL DEFAULT 'pending',payment_url TEXT,btc_amount TEXT,expires_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,product_id INTEGER,product_name TEXT NOT NULL,unit_price REAL NOT NULL,quantity INTEGER NOT NULL)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts(ip TEXT PRIMARY KEY,attempts INTEGER NOT NULL,first_attempt INTEGER NOT NULL)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL COLLATE NOCASE UNIQUE,password_hash TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
    $pdo->exec('CREATE TABLE IF NOT EXISTS customer_auth_attempts(bucket TEXT PRIMARY KEY,attempts INTEGER NOT NULL,started_at INTEGER NOT NULL)');
    $columns=$pdo->query('PRAGMA table_info(orders)')->fetchAll(PDO::FETCH_COLUMN,1);
    if (!in_array('inventory_reserved',$columns,true)) $pdo->exec('ALTER TABLE orders ADD COLUMN inventory_reserved INTEGER NOT NULL DEFAULT 0');
    if (!in_array('customer_id',$columns,true)) $pdo->exec('ALTER TABLE orders ADD COLUMN customer_id INTEGER REFERENCES customers(id)');
    $pdo->exec('CREATE INDEX IF NOT EXISTS orders_customer_id ON orders(customer_id)');
    foreach (['currency'=>"TEXT NOT NULL DEFAULT 'INR'",'total_sats'=>'INTEGER','payment_address'=>"TEXT NOT NULL DEFAULT ''",'customer_contact'=>"TEXT NOT NULL DEFAULT ''",'payer_name'=>"TEXT NOT NULL DEFAULT ''",'proof_file'=>"TEXT NOT NULL DEFAULT ''"] as $column=>$type) {
        if (!in_array($column,$columns,true)) $pdo->exec("ALTER TABLE orders ADD COLUMN $column $type");
    }
    $productColumns=$pdo->query('PRAGMA table_info(products)')->fetchAll(PDO::FETCH_COLUMN,1);
    if (!in_array('price_currency',$productColumns,true)) $pdo->exec("ALTER TABLE products ADD COLUMN price_currency TEXT NOT NULL DEFAULT 'INR'");
    $pdo->exec('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
    return $pdo;
}
function storage_dir(): string {
    static $dir=null; if(is_string($dir)) return $dir;
    $configured=getenv('BITCART_STORAGE_DIR');
    $dir=$configured!==false&&trim($configured)!==''?$configured:__DIR__.'/../storage';
    if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir)) throw new RuntimeException('Could not create the BitCart storage directory.');
    if(!is_writable($dir)) throw new RuntimeException('The BitCart storage directory is not writable.');
    return $dir;
}
function update_order_status(int $id, string $status): void {
    $pdo=db(); $pdo->beginTransaction();
    try {
        $s=$pdo->prepare('SELECT status,inventory_reserved,proof_file FROM orders WHERE id=?'); $s->execute([$id]); $order=$s->fetch();
        if (!$order) throw new RuntimeException('Order not found.');
        if (in_array($status,['payment_review','paid','processing','shipped'],true)&&$order['proof_file']==='') throw new RuntimeException('A payment screenshot must be submitted before review or approval.');
        if (in_array($status,['processing','shipped'],true)&&!in_array($order['status'],['paid','processing','shipped'],true)) throw new RuntimeException('Approve the payment before processing or shipping the order.');
        $reserved=(int)$order['inventory_reserved'];
        $s=$pdo->prepare('SELECT product_id,quantity FROM order_items WHERE order_id=?'); $s->execute([$id]);
        foreach ($s->fetchAll() as $item) {
            if ($status==='cancelled' && $reserved) {
                $q=$pdo->prepare('UPDATE products SET stock=stock+?,updated_at=CURRENT_TIMESTAMP WHERE id=?'); $q->execute([$item['quantity'],$item['product_id']]);
            } elseif ($order['status']==='cancelled' && $status!=='cancelled') {
                $q=$pdo->prepare('UPDATE products SET stock=stock-?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND stock>=?'); $q->execute([$item['quantity'],$item['product_id'],$item['quantity']]);
                if ($q->rowCount()!==1) throw new RuntimeException('Not enough stock to reopen this order.');
            }
        }
        if ($status==='cancelled') $reserved=0;
        elseif ($order['status']==='cancelled') $reserved=1;
        $s=$pdo->prepare('UPDATE orders SET status=?,inventory_reserved=?,updated_at=CURRENT_TIMESTAMP WHERE id=?'); $s->execute([$status,$reserved,$id]);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
function csrf_token(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { verify_csrf_value((string)($_POST['csrf']??'')); }
function verify_csrf_value(string $token): void { if(empty($_SESSION['csrf'])||!hash_equals($_SESSION['csrf'],$token)){http_response_code(419);exit('Session expired. Refresh and try again.');} }
function admin_config(): ?array { $p=storage_dir().'/config.php'; if(!is_file($p)) return null; $c=require $p; return is_array($c)?$c:null; }
function admin_logged_in(): bool { return !empty($_SESSION['admin']); }
function require_admin_post(): void { if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Method not allowed');} if(!admin_logged_in()){http_response_code(401);exit('Admin login required');} verify_csrf(); }
function login_allowed(string $ip): bool { $s=db()->prepare('SELECT attempts,first_attempt FROM login_attempts WHERE ip=?');$s->execute([$ip]);$r=$s->fetch(); if(!$r)return true; if(time()-(int)$r['first_attempt']>900){clear_login_attempts($ip);return true;} return (int)$r['attempts']<8; }
function record_login_attempt(string $ip): void { $s=db()->prepare('SELECT attempts,first_attempt FROM login_attempts WHERE ip=?');$s->execute([$ip]);$r=$s->fetch(); if(!$r||time()-(int)$r['first_attempt']>900){$q=db()->prepare('INSERT OR REPLACE INTO login_attempts(ip,attempts,first_attempt) VALUES(?,?,?)');$q->execute([$ip,1,time()]);}else{$q=db()->prepare('UPDATE login_attempts SET attempts=attempts+1 WHERE ip=?');$q->execute([$ip]);} }
function clear_login_attempts(string $ip): void { $s=db()->prepare('DELETE FROM login_attempts WHERE ip=?');$s->execute([$ip]); }
require_once __DIR__.'/commerce.php';
require_once __DIR__.'/customers.php';
db();
