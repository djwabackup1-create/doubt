<?php
declare(strict_types=1);
function e(mixed $value): string { return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8'); }
function setting(string $key, string $default=''): string {
    $s=db()->prepare('SELECT value FROM settings WHERE key=?'); $s->execute([$key]); $value=$s->fetchColumn(); return $value===false?$default:(string)$value;
}
function btc(int $sats): string { return number_format($sats/100000000,8,'.','').' BTC'; }
function price_label(array $p): string { return number_format((float)$p['price_inr'],$p['price_currency']==='BTC'?8:2,'.','').' '.$p['price_currency']; }
function product_sats(array $p): ?int {
    if ($p['price_currency']==='BTC') $value=(float)$p['price_inr']*100000000;
    elseif ($p['price_currency']==='USD' && (float)setting('usd_per_btc')>0) $value=(float)$p['price_inr']/(float)setting('usd_per_btc')*100000000;
    else return null;
    if (!is_finite($value)||$value<0.5||$value>2100000000000000) return null;
    return (int)round($value);
}
function public_products(): array {
    $rows=db()->query("SELECT * FROM products WHERE active=1 AND price_currency IN ('BTC','USD') ORDER BY id DESC")->fetchAll();
    return $rows;
}
function product_json(array $p): array { $sats=product_sats($p); return ['id'=>(int)$p['id'],'name'=>$p['name'],'price'=>$sats===null?null:$sats/100000000,'sats'=>$sats,'description'=>$p['description'],'price_label'=>price_label($p),'stock'=>(int)$p['stock'],'image'=>$p['image_url']]; }
function valid_bitcoin_address(string $address): bool {
    if (preg_match('/^[13][1-9A-HJ-NP-Za-km-z]{25,34}$/D',$address)) {
        $alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'; $bytes=[0];
        foreach (str_split($address) as $char) { $carry=strpos($alphabet,$char); foreach ($bytes as &$byte) { $carry+=$byte*58; $byte=$carry&255; $carry>>=8; } unset($byte); while ($carry) { $bytes[]=$carry&255; $carry>>=8; } }
        $decoded=str_repeat("\0",strspn($address,'1')).implode('',array_map('chr',array_reverse($bytes)));
        return strlen($decoded)===25 && hash_equals(substr(hash('sha256',hash('sha256',substr($decoded,0,21),true),true),0,4),substr($decoded,21));
    }
    if ($address!==strtolower($address)&&$address!==strtoupper($address)) return false;
    $address=strtolower($address);
    if (!preg_match('/^bc1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{11,87}$/D',$address)||strlen($address)>90) return false;
    $data=array_map(fn($c)=>strpos('qpzry9x8gf2tvdw0s3jn54khce6mua7l',$c),str_split(substr($address,3)));
    $version=$data[0]; if ($version>16) return false;
    $check=1; $generators=[0x3b6a57b2,0x26508e6d,0x1ea119fa,0x3d4233dd,0x2a1462b3];
    foreach (array_merge([3,3,0,2,3],$data) as $value) { $top=$check>>25; $check=(($check&0x1ffffff)<<5)^$value; for($i=0;$i<5;$i++) if(($top>>$i)&1) $check^=$generators[$i]; }
    if ($check!==($version===0?1:0x2bc830a3)) return false;
    $bits=0; $acc=0; $length=0;
    foreach (array_slice($data,1,-6) as $value) { $acc=(($acc<<5)|$value)&0xffff; $bits+=5; while($bits>=8) { $bits-=8; $length++; } }
    return $bits<5 && (($acc<<(8-$bits))&255)===0 && $length>=2 && $length<=40 && ($version!==0||in_array($length,[20,32],true));
}
function save_image_upload(string $field, string $kind, bool $required=false): ?string {
    $file=$_FILES[$field]??null;
    if (!$file || ($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) { if ($required) throw new RuntimeException('Choose an image to upload.'); return null; }
    if (!is_int($file['error'])||$file['error']!==UPLOAD_ERR_OK) throw new RuntimeException('Image upload failed. Check the server upload size limit.');
    if (!is_uploaded_file($file['tmp_name'])||filesize($file['tmp_name'])>10*1024*1024) throw new RuntimeException('Images must be no larger than 10 MB.');
    $info=@getimagesize($file['tmp_name']);
    $allowed=['image/jpeg','image/png','image/gif','image/webp','image/avif','image/bmp','image/x-ms-bmp','image/vnd.microsoft.icon','image/x-icon','image/tiff'];
    if (!$info||!in_array($info['mime']??'', $allowed,true)||$info[0]*$info[1]>40000000) throw new RuntimeException('Upload a valid raster image (JPG, PNG, GIF, WebP, AVIF, BMP, ICO or TIFF), up to 40 megapixels. SVG and unsupported formats must be exported to PNG or JPG.');
    $dir=storage_dir().'/uploads/'.$kind;
    if (!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir)) throw new RuntimeException('Could not create image storage.');
    $name=bin2hex(random_bytes(16)).'.bin';
    if (!move_uploaded_file($file['tmp_name'],$dir.'/'.$name)) throw new RuntimeException('Could not save uploaded image.');
    return $name;
}
function send_image(string $kind, string $name): never {
    if (!preg_match('/^[a-f0-9]{32}\.bin$/D',$name)) { http_response_code(404); exit; }
    $path=storage_dir().'/uploads/'.$kind.'/'.$name;
    if (!is_file($path)||!($info=@getimagesize($path))) { http_response_code(404); exit; }
    header('Content-Type: '.$info['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: default-src 'none'; sandbox"); header('Cache-Control: private, no-store'); header('Content-Length: '.filesize($path)); readfile($path); exit;
}
