<?php
declare(strict_types=1);
function current_customer(): ?array {
    $id=$_SESSION['customer_id']??null;
    if(!is_int($id)||$id<1) return null;
    $s=db()->prepare('SELECT id,username FROM customers WHERE id=?'); $s->execute([$id]);
    $customer=$s->fetch();
    if(!$customer) { unset($_SESSION['customer_id']); return null; }
    return $customer;
}
function require_customer(bool $json=false, string $next=''): array {
    $customer=current_customer();
    if($customer) return $customer;
    header('Cache-Control: no-store');
    if($json) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error'=>'Sign in to continue.']);
    } else header('Location: /login.php'.($next==='checkout'?'?next=checkout':''));
    exit;
}
function customer_authenticate(array $customer): void {
    session_regenerate_id(true);
    $_SESSION['customer_id']=(int)$customer['id'];
    unset($_SESSION['last_order'],$_SESSION['csrf']);
}
function customer_bucket(string $action, string $value): string { return hash('sha256',$action.':'.$value); }
function customer_session_bucket(string $action): string {
    if(empty($_SESSION['auth_limiter'])) $_SESSION['auth_limiter']=bin2hex(random_bytes(32));
    return customer_bucket($action,(string)$_SESSION['auth_limiter']);
}
function customer_attempt_allowed(string $bucket,int $limit): bool {
    $s=db()->prepare('SELECT attempts,started_at FROM customer_auth_attempts WHERE bucket=?');$s->execute([$bucket]);$row=$s->fetch();
    return !$row||time()-(int)$row['started_at']>=900||(int)$row['attempts']<$limit;
}
function customer_record_attempt(string $bucket): void {
    $now=time();
    $s=db()->prepare('INSERT INTO customer_auth_attempts(bucket,attempts,started_at) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN started_at<=? THEN 1 ELSE attempts+1 END,started_at=CASE WHEN started_at<=? THEN excluded.started_at ELSE started_at END');
    $s->execute([$bucket,$now,$now-900,$now-900]);
    db()->prepare('DELETE FROM customer_auth_attempts WHERE started_at<=?')->execute([$now-900]);
}
function customer_clear_attempts(string $bucket): void { db()->prepare('DELETE FROM customer_auth_attempts WHERE bucket=?')->execute([$bucket]); }
function valid_customer_username(string $username): bool { return (bool)preg_match('/^[A-Za-z0-9_-]{3,32}$/D',$username); }
function customer_auth_page(bool $signup): void {
    header('Cache-Control: no-store');header('Referrer-Policy: no-referrer');
    $next=(($_POST['next']??$_GET['next']??'')==='checkout')?'checkout':'';
    $destination=$next==='checkout'?'/checkout.php':'/';
    if(current_customer()) { header('Location: '.$destination);exit; }
    $error='';$username='';
    if($_SERVER['REQUEST_METHOD']==='POST') {
        verify_csrf();
        $username=is_string($_POST['username']??null)?trim($_POST['username']):'';
        $password=is_string($_POST['password']??null)?$_POST['password']:'';
        $sessionBucket=customer_session_bucket($signup?'signup':'login');
        $userBucket=customer_bucket('username',strtolower($username));
        if(!customer_attempt_allowed($sessionBucket,$signup?5:30)||(!$signup&&!customer_attempt_allowed($userBucket,8))) {
            http_response_code(429);$error='Too many attempts. Wait 15 minutes and try again.';
        } elseif($signup) {
            customer_record_attempt($sessionBucket);
            $confirm=is_string($_POST['confirm']??null)?$_POST['confirm']:'';
            if(!valid_customer_username($username)) $error='Choose a username with 3–32 letters, numbers, underscores or hyphens.';
            elseif(mb_strlen($password)<12||strlen($password)>72||str_contains($password,"\0")) $error='Use at least 12 characters and no more than 72 bytes for your password.';
            elseif(!hash_equals($password,$confirm)) $error='Passwords do not match.';
            else {
                try {
                    $hash=password_hash($password,PASSWORD_DEFAULT);
                    $s=db()->prepare('INSERT INTO customers(username,password_hash) VALUES(?,?)');$s->execute([$username,$hash]);
                    customer_authenticate(['id'=>(int)db()->lastInsertId()]);header('Location: '.$destination);exit;
                } catch(PDOException $exception) {
                    if(($exception->errorInfo[1]??null)!==19) throw $exception;
                    $error='That username is unavailable. Choose another.';
                }
            }
        } else {
            customer_record_attempt($sessionBucket);customer_record_attempt($userBucket);
            $s=db()->prepare('SELECT id,password_hash FROM customers WHERE username=?');$s->execute([$username]);$customer=$s->fetch();
            $dummy='$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
            $verified=strlen($password)<=72&&!str_contains($password,"\0")&&password_verify($password,$customer['password_hash']??$dummy);
            if(!$customer||!valid_customer_username($username)||!$verified) $error='Incorrect username or password.';
            else {
                if(password_needs_rehash($customer['password_hash'],PASSWORD_DEFAULT)) db()->prepare('UPDATE customers SET password_hash=? WHERE id=?')->execute([password_hash($password,PASSWORD_DEFAULT),$customer['id']]);
                customer_clear_attempts($userBucket);customer_clear_attempts($sessionBucket);
                customer_authenticate($customer);header('Location: '.$destination);exit;
            }
        }
        if($error!==''&&http_response_code()!==429) http_response_code(400);
    } elseif($_SERVER['REQUEST_METHOD']!=='GET') { http_response_code(405);exit('Method not allowed'); }
    require __DIR__.'/customer-form.php';
}
