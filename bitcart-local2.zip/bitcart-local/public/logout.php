<?php
require_once __DIR__.'/../src/bootstrap.php';
if($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405);exit('Method not allowed'); }
verify_csrf();
unset($_SESSION['customer_id'],$_SESSION['last_order'],$_SESSION['csrf']);
session_regenerate_id(true);
header('Location: /');exit;
