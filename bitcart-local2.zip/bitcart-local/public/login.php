<?php
require_once __DIR__.'/../src/bootstrap.php';
customer_auth_page(false);
