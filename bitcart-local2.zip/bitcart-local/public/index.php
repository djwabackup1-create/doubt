<?php
require_once __DIR__ . '/../src/bootstrap.php';
header('Cache-Control: private, no-store');
$customer=require_customer();
$products = public_products();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BitCart — Independent Goods</title>
  <link rel="stylesheet" href="/assets/style.css?v=4">
</head>
<body>
<header class="topbar">
  <a class="brand" href="/">BIT<span>CART</span><small>INDEPENDENT GOODS</small></a>
  <nav><a href="#products">Shop</a><a href="/account.php">My account</a><form method="post" action="/logout.php" class="inline-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><button class="text-button">Sign out</button></form><button class="text-button" id="openWishlist">Wishlist <span id="wishlistCount">0</span></button><button class="cart-button" id="openCart">Cart <span id="cartCount">0</span></button></nav>
</header>
<main>
  <section class="hero">
    <div class="eyebrow">CURATED GOODS · SIMPLE CHECKOUT</div>
    <h1>Good things.<br><em>No unnecessary noise.</em></h1>
    <p>A focused collection from one independent company. Browse, save your favourites, and check out with Bitcoin.</p>
    <a class="primary-link" href="#products">Explore the collection <span>↘</span></a>
    <div class="hero-note"><span class="dot"></span> Bitcoin-only checkout · Account shopping</div>
  </section>
  <section id="products" class="catalog">
    <div class="section-heading"><div><div class="eyebrow">THE COLLECTION</div><h2>Latest arrivals</h2></div><div class="catalog-tools"><input id="search" placeholder="Search products…" aria-label="Search products"><span id="catalogCount"><?= count($products) ?> items</span></div></div>
    <div id="catalogEmpty" class="empty-state" <?= $products?'hidden':'' ?>>Your collection is waiting to be stocked.<br><small>Open the admin panel to add the first product.</small></div>
    <div class="product-grid" id="productGrid">
      <?php foreach ($products as $p): $canBuy=(int)$p['stock']>0&&product_sats($p)!==null; ?>
      <article class="product-card" data-name="<?= htmlspecialchars(strtolower($p['name']), ENT_QUOTES, 'UTF-8') ?>">
        <div class="product-image">
          <?php if ($p['image_url']): ?><img src="<?= htmlspecialchars($p['image_url'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8') ?>" loading="lazy"><?php else: ?><div class="image-placeholder"><span>BC</span></div><?php endif; ?>
          <button class="heart" data-wish="<?= (int)$p['id'] ?>" aria-label="Add to wishlist">♡</button>
        </div>
        <div class="product-info"><div><h3><?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8') ?></h3><p><?= htmlspecialchars(mb_strimwidth($p['description'], 0, 92, '…'), ENT_QUOTES, 'UTF-8') ?></p></div>
          <div class="product-bottom"><strong><?= e(price_label($p)) ?></strong><label class="product-quantity">Qty<input id="quantity-<?= (int)$p['id'] ?>" type="number" min="1" max="<?= min(100, (int)$p['stock']) ?>" value="1" <?= !$canBuy ? 'disabled' : '' ?>></label><button class="add-button" data-add="<?= (int)$p['id'] ?>" <?= !$canBuy ? 'disabled' : '' ?>><?= (int)$p['stock'] < 1 ? 'Sold out' : (!$canBuy?'Payment setup pending':'Add to cart') ?></button></div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </section>
  <section class="bottom-banner"><div><div class="eyebrow">PAY WITH BITCOIN</div><h2>Modern checkout.<br><em>Clear order status.</em></h2></div><p>Pay to our Bitcoin address, submit a screenshot, and wait for manual approval.</p></section>
</main>
<footer><a class="brand small-brand" href="/">BIT<span>CART</span></a><span>© <?= date('Y') ?> BitCart. Built for one company.</span><a class="admin-entry" href="/admin.php">Admin</a></footer>
<div class="overlay" id="overlay" hidden></div>
<aside class="drawer" id="cartDrawer" aria-label="Shopping cart" hidden><div class="drawer-head"><h2>Your cart</h2><button class="close-drawer" aria-label="Close">×</button></div><p id="cartStatus" class="muted small" role="status" aria-live="polite"></p><div id="cartItems"></div><div class="drawer-foot"><button id="clearCart" class="text-button" type="button">Clear cart</button><div class="total-line"><span>Subtotal</span><strong id="cartTotal">0.00000000 BTC</strong></div><button class="primary-button" id="checkoutButton">Continue to checkout</button><p class="muted">Secure checkout · Bitcoin only</p></div></aside>
<aside class="drawer" id="wishlistDrawer" aria-label="Wishlist" hidden><div class="drawer-head"><h2>Saved items</h2><button class="close-drawer" aria-label="Close">×</button></div><div id="wishlistItems"></div></aside>
<script>window.BITCART_PRODUCTS = <?= json_encode(array_map('product_json',$products),JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>;</script>
<script src="/assets/cart.js?v=5"></script><script src="/assets/app.js?v=5"></script>
</body></html>
l
