<?php
require_once __DIR__.'/../../src/bootstrap.php';
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); header('Referrer-Policy: no-referrer');
if($_SERVER['REQUEST_METHOD']!=='GET') { http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit; }
$customer=require_customer(true);
$s=db()->prepare('SELECT status FROM orders WHERE id=? AND public_ref=? AND customer_id=?'); $s->execute([(int)($_GET['order']??0),(string)($_GET['ref']??''),(int)$customer['id']]); $status=$s->fetchColumn();
if($status===false) { http_response_code(404); echo json_encode(['error'=>'Order not found']); exit; }
echo json_encode(['status'=>$status]);
