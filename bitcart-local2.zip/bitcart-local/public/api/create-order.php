<?php
require_once __DIR__ . '/../../src/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit; }
$customer=require_customer(true);
try {
    $data=json_decode(file_get_contents('php://input'), true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($data)) throw new RuntimeException('Invalid checkout details.');
    verify_csrf_value((string)($data['csrf']??''));
    $name=trim((string)($data['name']??'')); $contact=trim((string)($data['contact']??'')); $address=trim((string)($data['address']??'')); $city=trim((string)($data['city']??'')); $note=trim((string)($data['note']??''));
    if ($name==='' || mb_strlen($name)>120 || $contact==='' || mb_strlen($contact)>190 || mb_strlen($address)>500 || mb_strlen($city)>100 || mb_strlen($note)>500) throw new RuntimeException('Please check your contact and delivery details.');
    $items=$data['items']??[]; if (!is_array($items)||count($items)<1||count($items)>50) throw new RuntimeException('Your cart is empty or invalid.');
    $customerId=(int)$customer['id'];
    $fingerprint=hash('sha256', json_encode([$customerId,$name,$contact,$address,$city,$note,$items]));
    if (isset($_SESSION['last_order']) && $_SESSION['last_order']['fingerprint']===$fingerprint && time()-$_SESSION['last_order']['time']<300) { echo json_encode($_SESSION['last_order']['result']); exit; }
    $paymentAddress=setting('bitcoin_address'); if(!valid_bitcoin_address($paymentAddress)) throw new RuntimeException('The store has not configured its Bitcoin receiving address yet. Please contact the store.');
    $pdo=db(); $pdo->beginTransaction(); $totalSats=0; $validated=[]; $seen=[];
    foreach($items as $item) {
        if (!is_array($item)) throw new RuntimeException('Invalid cart item.');
        $id=filter_var($item['id']??null,FILTER_VALIDATE_INT); $qty=filter_var($item['qty']??null,FILTER_VALIDATE_INT);
        if(!$id||!$qty||$qty<1||$qty>100) throw new RuntimeException('Invalid cart item.');
        if (isset($seen[$id])) throw new RuntimeException('Duplicate cart item. Refresh your cart.');
        $seen[$id]=true;
        $s=$pdo->prepare('SELECT * FROM products WHERE id=?'); $s->execute([$id]); $p=$s->fetch();
        if(!$p||!(int)$p['active']||(int)$p['stock']<$qty) throw new RuntimeException('A product is unavailable or no longer has enough stock. Refresh your cart.');
        $sats=product_sats($p); if($sats===null) throw new RuntimeException('A product needs a valid BTC or USD price and exchange rate.');
        $totalSats += $sats*$qty; if($totalSats>2100000000000000) throw new RuntimeException('Order total is too large.');
        $validated[]=['id'=>$id,'name'=>$p['name'],'price'=>$sats/100000000,'qty'=>$qty];
    }
    if (isset($data['expected_total']) && (!is_numeric($data['expected_total']) || abs($totalSats-(float)$data['expected_total']*100000000)>0.5)) throw new RuntimeException('Product prices changed. Refresh checkout and review the new total before ordering.');
    $total=$totalSats/100000000;
    $ref=bin2hex(random_bytes(24));
    $s=$pdo->prepare("INSERT INTO orders(public_ref,customer_name,customer_email,delivery_address,city,note,total_inr,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'pending',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)");
    $s->execute([$ref,$name,'',$address,$city,$note,$total]); $orderId=(int)$pdo->lastInsertId();
    $is=$pdo->prepare('INSERT INTO order_items(order_id,product_id,product_name,unit_price,quantity) VALUES(?,?,?,?,?)');
    foreach($validated as $v) $is->execute([$orderId,$v['id'],$v['name'],$v['price'],$v['qty']]);
    $reserve=$pdo->prepare('UPDATE products SET stock=stock-?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND active=1 AND stock>=?');
    foreach ($validated as $v) { $reserve->execute([$v['qty'],$v['id'],$v['qty']]); if ($reserve->rowCount()!==1) throw new RuntimeException('Stock changed. Please refresh your cart.'); }
    $pdo->prepare("UPDATE orders SET inventory_reserved=1,currency='BTC',total_sats=?,payment_address=?,customer_contact=?,customer_id=? WHERE id=?")->execute([$totalSats,$paymentAddress,$contact,$customerId,$orderId]);
    $pdo->commit();
    $result=['ok'=>true,'url'=>'/payment.php?order='.$orderId.'&ref='.$ref];
    $_SESSION['last_order']=['fingerprint'=>$fingerprint,'time'=>time(),'result'=>$result];
    echo json_encode($result);
} catch(Throwable $e) {
    if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400); echo json_encode(['error'=>$e instanceof RuntimeException?$e->getMessage():'Could not create the order. Please try again.']);
}
