(() => {
  const products = window.BITCART_PRODUCTS || [], store = window.BitCart;
  let cart = store.read(), wishlist = [];
  try { const saved = JSON.parse(localStorage.getItem('bitcart_wishlist_v1') || '[]'); if (Array.isArray(saved)) wishlist = [...new Set(saved)].filter(id => products.some(p => p.id === id)); } catch {}
  const el = id => document.getElementById(id);
  const money = n => Number(n).toFixed(8) + ' BTC';
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function close() { el('overlay').hidden = el('cartDrawer').hidden = el('wishlistDrawer').hidden = true; document.body.classList.remove('drawer-open'); }
  function open(id) { close(); el('overlay').hidden = el(id).hidden = false; document.body.classList.add('drawer-open'); }
  function render() {
    el('cartCount').textContent = cart.reduce((sum, x) => sum + x.qty, 0);
    el('wishlistCount').textContent = wishlist.length;
    document.querySelectorAll('[data-wish]').forEach(b => { const on = wishlist.includes(Number(b.dataset.wish)); b.classList.toggle('wished', on); b.textContent = on ? '♥' : '♡'; b.setAttribute('aria-pressed', String(on)); });
    el('cartItems').innerHTML = cart.map(x => { const p = products.find(p => p.id === x.id); return `<div class="cart-item"><div><strong>${esc(p.name)}</strong><p>${money(p.price)} each · ${money(p.price*x.qty)}</p></div><div class="qty-controls"><button data-minus="${p.id}" aria-label="Decrease quantity">−</button><input type="number" data-quantity="${p.id}" min="1" max="${store.limit(p.id)}" value="${x.qty}" aria-label="Quantity for ${esc(p.name)}"><button data-plus="${p.id}" aria-label="Increase quantity" ${x.qty >= store.limit(p.id) ? 'disabled' : ''}>+</button><button class="remove-item" data-remove="${p.id}">Remove</button></div></div>`; }).join('') || '<p class="muted">Your cart is empty. Add a product to get started.</p>';
    el('cartTotal').textContent = money(cart.reduce((sum, x) => sum + products.find(p => p.id === x.id).price*x.qty, 0));
    el('checkoutButton').disabled = el('clearCart').disabled = !cart.length;
    el('wishlistItems').innerHTML = wishlist.map(id => { const p = products.find(p => p.id === id); return `<div class="cart-item"><strong>${esc(p.name)}</strong><div>${money(p.price)} <button data-add="${p.id}" class="small-button" ${store.limit(id) ? '' : 'disabled'}>Add to cart</button><button data-unwish="${p.id}" class="remove-item">Remove</button></div></div>`; }).join('') || '<p class="muted">No saved items yet.</p>';
  }
  function save() { cart = store.write(cart); try { localStorage.setItem('bitcart_wishlist_v1', JSON.stringify(wishlist)); } catch {} render(); }
  let refreshing = false;
  async function refreshProducts() {
    if (refreshing) return;
    refreshing = true;
    try {
      const response = await fetch('/api/products.php', {cache:'no-store'});
      if (!response.ok) return;
      const data = await response.json();
      if (!Array.isArray(data.products)) return;
      products.splice(0, products.length, ...data.products);
      const before = JSON.stringify(cart);
      cart = store.write(cart);
      wishlist = wishlist.filter(id => products.some(p => p.id === id));
      const grid = el('productGrid');
      if (grid) {
        const quantities = new Map(Array.from(grid.querySelectorAll('.product-quantity input'), input => [input.id, input.value]));
        grid.innerHTML = products.map(product => {
          const id = product.id, limit = store.limit(id), disabled = !limit;
          const label = product.stock < 1 ? 'Sold out' : product.price === null ? 'Payment setup pending' : 'Add to cart';
          const quantity = Math.max(1, Math.min(limit || 1, Number(quantities.get(`quantity-${id}`)) || 1));
          // Only local upload URLs are used for product images.
          const image = /^\/media\.php\?image=[a-f0-9]{32}\.bin$/.test(product.image || '')
            ? `<img src="${esc(product.image)}" alt="${esc(product.name)}" loading="lazy">`
            : '<div class="image-placeholder"><span>BC</span></div>';
          return `<article class="product-card" data-name="${esc(product.name.toLowerCase())}"><div class="product-image">${image}<button class="heart" data-wish="${id}" aria-label="Add to wishlist">♡</button></div><div class="product-info"><div><h3>${esc(product.name)}</h3><p>${esc((product.description || '').slice(0,92))}</p></div><div class="product-bottom"><strong>${esc(product.price_label || money(product.price))}</strong><label class="product-quantity">Qty<input id="quantity-${id}" type="number" min="1" max="${limit}" value="${quantity}" ${disabled ? 'disabled' : ''}></label><button class="add-button" data-add="${id}" ${disabled ? 'disabled' : ''}>${label}</button></div></div></article>`;
        }).join('');
        const query = el('search').value.toLowerCase();
        grid.querySelectorAll('.product-card').forEach(card => card.hidden = !card.dataset.name.includes(query));
        if (el('catalogCount')) el('catalogCount').textContent = products.length + ' items';
        if (el('catalogEmpty')) el('catalogEmpty').hidden = products.length > 0;
      }
      render();
      if (before !== JSON.stringify(cart)) el('cartStatus').textContent = 'Availability changed. Your cart has been updated; please review it.';
    } catch { /* Checkout independently validates current price and stock. */ }
    finally { refreshing = false; }
  }
  document.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b || b.disabled) return;
    const id = Number(b.dataset.add || b.dataset.wish || b.dataset.unwish || b.dataset.remove || b.dataset.minus || b.dataset.plus);
    if (b.dataset.add) {
      if (!store.limit(id)) return;
      const input = el(`quantity-${id}`), requested = input && b.closest('.product-card') ? Number(input.value) : 1;
      if (!Number.isInteger(requested) || requested < 1 || requested > store.limit(id)) { el('cartStatus').textContent = 'Choose a quantity between 1 and ' + store.limit(id) + '.'; if (input) input.reportValidity(); return; }
      const item = cart.find(x => x.id === id), before = item?.qty || 0;
      if (item) item.qty = Math.min(store.limit(id), item.qty + requested); else cart.push({id, qty:requested});
      save(); open('cartDrawer'); el('cartStatus').textContent = before === store.limit(id) ? 'You already have the maximum available quantity.' : 'Added to your cart.'; return;
    }
    if (b.dataset.wish) { wishlist = wishlist.includes(id) ? wishlist.filter(x => x !== id) : [...wishlist, id]; save(); return; }
    if (b.dataset.unwish) { wishlist = wishlist.filter(x => x !== id); save(); return; }
    if (b.dataset.remove) { cart = cart.filter(x => x.id !== id); save(); return; }
    if (b.dataset.minus || b.dataset.plus) { const item = cart.find(x => x.id === id); if (item) item.qty += b.dataset.plus ? 1 : -1; save(); return; }
    if (b.id === 'clearCart') { cart = []; save(); el('cartStatus').textContent = 'Cart cleared.'; }
    if (b.id === 'openCart') { cart = store.read(); render(); open('cartDrawer'); refreshProducts(); }
    if (b.id === 'openWishlist') open('wishlistDrawer');
    if (b.classList.contains('close-drawer')) close();
  });
  document.addEventListener('change', e => { const id = Number(e.target.dataset.quantity); if (!id) return; const item = cart.find(x => x.id === id); if (item) item.qty = Math.max(1, Math.min(store.limit(id), Math.trunc(Number(e.target.value)) || 1)); save(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  window.addEventListener('storage', () => { cart = store.read(); render(); });
  window.addEventListener('focus', refreshProducts);
  setInterval(refreshProducts, 15000);
  el('overlay').addEventListener('click', close);
  el('checkoutButton').addEventListener('click', () => { if (cart.length) { save(); location.href = '/checkout.php'; } });
  el('search').addEventListener('input', e => { const q = e.target.value.toLowerCase(); document.querySelectorAll('.product-card').forEach(c => c.hidden = !c.dataset.name.includes(q)); });
  render();
})();
