(() => {
  const key = 'bitcart_cart_v1', products = window.BITCART_PRODUCTS || [];
  let memory = [];
  const limit = id => { const product = products.find(p => p.id === id); return product?.price === null ? 0 : Math.min(100, Math.max(0, Number(product?.stock) || 0)); };
  function normalize(value) {
    const rows = new Map();
    if (!Array.isArray(value)) return [];
    for (const item of value) {
      if (!item || !Number.isInteger(item.id) || !Number.isInteger(item.qty) || item.qty < 1 || !limit(item.id)) continue;
      rows.set(item.id, Math.min(limit(item.id), (rows.get(item.id) || 0) + item.qty));
    }
    return Array.from(rows, ([id, qty]) => ({ id, qty }));
  }
  function read() { try { memory = normalize(JSON.parse(localStorage.getItem(key) || '[]')); } catch { memory = normalize(memory); } return memory; }
  function write(items) { memory = normalize(items); try { localStorage.setItem(key, JSON.stringify(memory)); } catch {} return memory; }
  window.BitCart = { read, write, limit, clear() { write([]); try { localStorage.removeItem(key); } catch {} } };
})();
