<?php
require_once __DIR__ . '/../src/bootstrap.php';
header('Cache-Control: private, no-store');
$token = csrf_token();
$customer=require_customer(false,'checkout');
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Checkout — BitCart</title><link rel="stylesheet" href="/assets/style.css?v=4"></head>
<body><header class="topbar"><a class="brand" href="/">BIT<span>CART</span><small>INDEPENDENT GOODS</small></a><a href="/">← Back to shop</a></header>
<main class="checkout-layout"><section><div class="eyebrow">SECURE CHECKOUT</div><h1>Almost yours.</h1><p class="muted">Enter a name and one way to contact you, then create your order. Contact details are collected only when you place an order.</p>
<p>Signed in as <a href="/account.php"><?= e($customer['username']) ?></a>.</p>
<form id="checkoutForm"><input type="hidden" name="csrf" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
<label>Name / what should we call you?<input name="name" required maxlength="120" value="<?= e($customer['username']??'') ?>"></label>
<label>Contact information (email, phone, or messaging handle)<input name="contact" required maxlength="190"></label>
<label>Delivery address (only if delivery is needed)<textarea name="address" maxlength="500" rows="3" autocomplete="street-address"></textarea></label>
<label>City (optional)<input name="city" maxlength="100" autocomplete="address-level2"></label>
<label>Order note <span class="muted">(optional)</span><textarea name="note" maxlength="500" rows="2"></textarea></label>
<button class="primary-button" type="submit">Create Bitcoin order ↗</button><div id="checkoutMessage" class="notice" hidden></div></form></section>
<aside class="checkout-summary"><div class="eyebrow">YOUR ORDER</div><p class="muted small">1. Review items · 2. Enter contact details · 3. Create order · 4. Pay Bitcoin & submit screenshot</p><div id="checkoutItems"></div><a href="/">Edit cart / continue shopping</a><div class="total-line"><span>Total</span><strong id="checkoutTotal">0.00000000 BTC</strong></div><p class="muted small">USD prices are converted using the store’s posted rate: 1 BTC = <?= e(setting('usd_per_btc','not configured')) ?> USD. Your exact BTC total is fixed when the order is created. Payment is approved manually after you submit a screenshot.</p></aside></main>
<script>window.BITCART_PRODUCTS = <?= json_encode(array_map('product_json',public_products()),JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>;</script><script src="/assets/cart.js?v=5"></script><script src="/assets/checkout.js?v=4"></script></body></html>
