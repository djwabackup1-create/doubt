<?php
require_once __DIR__.'/../src/bootstrap.php';
if (isset($_GET['image'])) {
    if(!current_customer()&&!admin_logged_in()) { http_response_code(401); exit('Sign in to continue.'); }
    send_image('products',(string)$_GET['image']);
}
if (!admin_logged_in()) { http_response_code(401); exit('Admin login required.'); }
$s=db()->prepare('SELECT proof_file FROM orders WHERE id=?'); $s->execute([(int)($_GET['proof']??0)]);
send_image('proofs',(string)$s->fetchColumn());
