"""Run isolated HTTP integration checks: python tests/smoke.py."""
import base64
import http.cookiejar
import json
import os
from pathlib import Path
import re
import socket
import sqlite3
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
checks = 0

def check(condition, label):
    global checks
    assert condition, label
    checks += 1
    print('PASS', label)

with tempfile.TemporaryDirectory(prefix='bitcart-test-') as storage:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    env = dict(os.environ, BITCART_STORAGE_DIR=storage)
    with tempfile.TemporaryFile() as log:
        server = subprocess.Popen(['php', '-S', f'127.0.0.1:{port}', '-t', str(ROOT / 'public')], cwd=ROOT, env=env, stdout=log, stderr=log)
        client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        def request(path, data=None, json_body=False, files=None, opener=None):
            headers = {}
            if files is not None:
                boundary = 'BitCartSmokeBoundary123456'
                parts=[]
                for key, value in (data or {}).items():
                    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
                for key, filename, content, mime in files:
                    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"; filename="{filename}"\r\nContent-Type: {mime}\r\n\r\n'.encode()+content+b'\r\n')
                data=b''.join(parts)+f'--{boundary}--\r\n'.encode()
                headers['Content-Type']='multipart/form-data; boundary='+boundary
            elif data is not None:
                if json_body:
                    data = json.dumps(data).encode()
                    headers['Content-Type'] = 'application/json'
                else:
                    data = urllib.parse.urlencode(data).encode()
            try:
                response = (opener or client).open(urllib.request.Request(f'http://127.0.0.1:{port}' + path, data=data, headers=headers), timeout=5)
            except urllib.error.HTTPError as error:
                response = error
            return response.status, response.read().decode()
        def token(html):
            return re.search(r'name="csrf" value="([^"]+)"', html)[1]
        try:
            for attempt in range(50):
                try:
                    status, html = request('/')
                    break
                except urllib.error.URLError:
                    time.sleep(.1)
            check(status == 200 and 'Welcome back' in html, 'Storefront requires login')
            check('Admin access' in request('/admin.php')[1], 'Admin requires login')
            check(request('/admin-product.php', {})[0] == 401, 'Unauthenticated product write blocked')
            csrf = token(request('/setup.php')[1])
            check('at least 11' in request('/setup.php', dict(csrf=csrf, password='short', confirm='short'))[1], 'Weak setup password rejected')
            password = 'Temporary-test-password-123!'
            check('Admin access' in request('/setup.php', dict(csrf=csrf, password=password, confirm=password))[1], 'Initial setup')
            check(request('/setup.php')[0] == 403, 'Repeated setup blocked')
            csrf = token(request('/admin-login.php')[1])
            check('Incorrect password' in request('/admin-login.php', dict(csrf=csrf, password='incorrect'))[1], 'Wrong password rejected')
            status, html = request('/admin-login.php', dict(csrf=csrf, password=password))
            check(status == 200 and 'Store management' in html, 'Admin login')
            signup_csrf=token(request('/signup.php')[1])
            status,html=request('/signup.php',dict(csrf=signup_csrf,username='Smoke_Customer',password=password,confirm=password))
            check(status==200 and 'My account' in html,'Customer signs up before shopping')
            csrf = token(html)
            address='1BoatSLRHtKNngkdXEeobR76b53LETtpyT'
            check(request('/admin-settings.php', dict(csrf=csrf,bitcoin_address='invalid',usd_per_btc='100000'))[0] == 400, 'Invalid Bitcoin address rejected')
            check(request('/admin-settings.php', dict(csrf=csrf,bitcoin_address=address,usd_per_btc='100000'))[0] == 200, 'Save receiving address and manual USD exchange rate')
            image=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=')
            upload=[('image','product.png',image,'image/png')]
            product=dict(csrf=csrf,name='Test <Goods>',description='Example description',price='12.50',currency='USD',stock='3',active='1')
            check(request('/admin-product.php',dict(product,csrf='bad'))[0] == 419,'Product CSRF protection')
            check(request('/admin-product.php',dict(product,stock='-1'))[0] == 400,'Negative stock rejected')
            check(request('/admin-product.php',dict(product,currency='INR'))[0] == 400,'Unsupported price currency rejected')
            check(request('/admin-product.php',product,files=[('image','fake.png',b'<?php echo 1;','image/png')])[0] == 400,'Disguised executable upload rejected')
            check(request('/admin-product.php',product,files=[('image','vector.svg',b'<svg xmlns="http://www.w3.org/2000/svg"></svg>','image/svg+xml')])[0] == 400,'Active SVG upload rejected')
            check(request('/admin-product.php',product,files=upload)[0] == 200,'Create USD product with uploaded image')
            connection=sqlite3.connect(Path(storage)/'store.sqlite')
            product_id,image_url=connection.execute('SELECT id,image_url FROM products').fetchone()
            check(image_url.startswith('/media.php?image='),'Product image stored locally')
            anonymous=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
            # Binary image response is read separately because request() decodes text.
            check(request(image_url,opener=anonymous)[0]==401,'Anonymous product image blocked')
            with client.open(f'http://127.0.0.1:{port}'+image_url) as response:
                check(response.status==200 and response.headers['Content-Type']=='image/png' and response.read()==image,'Uploaded product image displays after login')
            html=request('/')[1]
            check('Test &lt;Goods&gt;' in html and '12.50 USD' in html and '₹' not in html,'Storefront escapes names and displays USD prices')
            check('type="file"' in request(f'/admin.php?edit={product_id}')[1] and 'image_url' not in request('/admin.php')[1],'Admin uses upload instead of image URL')
            checkout=request('/checkout.php')[1]
            products=json.loads(re.search(r'window.BITCART_PRODUCTS = (.*?);',checkout)[1])
            check(products[0]['sats']==12500,'USD price converts to exact integer satoshis')
            check('name="contact"' in checkout and 'name="email"' not in checkout,'Checkout asks for one flexible contact method')
            check('name="address" required' not in checkout,'Delivery address is optional')
            order=dict(csrf=token(checkout),name='Chosen Nickname',contact='@test-buyer',items=[dict(id=product_id,qty=2)],expected_total=0.00025)
            check(request('/api/create-order.php')[0]==405,'Order API rejects GET')
            check(request('/api/create-order.php',dict(order,csrf='bad'),True)[0]==419,'Order CSRF protection')
            check(request('/api/create-order.php',dict(order,contact=''),True)[0]==400,'Contact is required only when placing order')
            check(request('/api/create-order.php',dict(order,items=[]),True)[0]==400,'Empty cart rejected')
            check(request('/api/create-order.php',dict(order,items=[dict(id=product_id,qty=4)]),True)[0]==400,'Insufficient stock rejected')
            check(request('/api/create-order.php',dict(order,items=[dict(id=product_id,qty=2),dict(id=product_id,qty=2)]),True)[0]==400,'Duplicate cart product rejected')
            check(request('/api/create-order.php',dict(order,expected_total=1),True)[0]==400,'Changed price requires review')
            status,body=request('/api/create-order.php',order,True);result=json.loads(body)
            check(status==200 and result['ok'],'Customer creates manual Bitcoin order')
            saved=connection.execute('SELECT total_sats,currency,status,customer_name,customer_contact,customer_email,delivery_address,payment_address FROM orders').fetchone()
            check(saved==(25000,'BTC','pending','Chosen Nickname','@test-buyer','','',address),'BTC amount, chosen name, contact and address snapshot saved without extra delivery data')
            check(connection.execute('SELECT stock FROM products').fetchone()[0]==1,'Order reserves stock')
            retry=json.loads(request('/api/create-order.php',order,True)[1])
            check(retry['url']==result['url'] and connection.execute('SELECT count(*) FROM orders').fetchone()[0]==1,'Checkout retry reuses order')
            payment=request(result['url'])[1]
            check(address in payment and 'bitcoinQr' in payment and '0.00025000 BTC' in payment,'Payment shows exact BTC amount, address and local QR target')
            request('/admin-settings.php',dict(csrf=csrf,bitcoin_address='3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy',usd_per_btc='200000'))
            frozen=request(result['url'])[1]
            check(address in frozen and '0.00025000 BTC' in frozen,'Existing order amount and address remain fixed after settings change')
            request('/admin-settings.php',dict(csrf=csrf,bitcoin_address=address,usd_per_btc='100000'))
            check('Chosen Nickname' in payment and 'payment_screenshot' in payment,'Payment asks for screenshot and prefills chosen name')
            check(request('/assets/vendor/qrcodegen.js')[0]==200,'QR encoder served locally')
            check(request('/payment.php?order=1&ref=wrong')[0]==404,'Private order reference enforced')
            status_url=result['url'].replace('/payment.php','/api/order-status.php')
            check(json.loads(request(status_url)[1])['status']=='pending','Private live order status endpoint')
            check(request('/api/order-status.php?order=1&ref=wrong')[0]==404,'Live status requires private order reference')
            check(request('/media.php?proof=1',opener=anonymous)[0]==401,'Screenshot access requires admin')
            check(request('/admin-review.php?order=1',opener=anonymous)[1].find('Admin access')>=0,'Order review requires admin')
            check(request('/admin-order.php',dict(csrf=csrf,id=1,status='paid'))[0]==400,'Order cannot be approved without screenshot')
            check(request(result['url'],dict(csrf=csrf,payer_name='',payment_sent=1),files=[('payment_screenshot','proof.png',image,'image/png')])[0]==400,'Payment submission requires payer name')
            check(request(result['url'],dict(csrf=csrf,payer_name='Chosen Nickname',payment_sent=1),files=[])[0]==400,'Payment submission requires screenshot')
            check(request(result['url'],dict(csrf='bad',payer_name='Chosen Nickname',payment_sent=1),files=[('payment_screenshot','proof.png',image,'image/png')])[0]==419,'Payment submission CSRF protection')
            check(request(result['url'],dict(csrf=csrf,payer_name='Chosen Nickname',payment_sent=1),files=[('payment_screenshot','proof.png',image,'image/png')])[0]==200,'Screenshot submitted for manual review')
            check(connection.execute('SELECT status,payer_name FROM orders').fetchone()==('payment_review','Chosen Nickname'),'Screenshot does not automatically approve payment')
            review=request('/admin-review.php?order=1')[1]
            check('@test-buyer' in review and 'Chosen Nickname' in review and '/media.php?proof=1' in review,'Admin sees contact, payer name and screenshot')
            with client.open(f'http://127.0.0.1:{port}/media.php?proof=1') as response:
                check(response.read()==image,'Authenticated admin can inspect original screenshot')
            check(request('/admin-order.php',dict(csrf=csrf,id=1,status='processing'))[0]==400,'Shipping flow requires payment approval first')
            check(request('/admin-order.php',dict(csrf=csrf,id=1,status='paid'))[0]==200 and 'manually approved' in request(result['url'])[1],'Admin manually approves payment')
            check(json.loads(request(status_url)[1])['status']=='paid','Live status reflects manual approval')
            check(request(result['url'],dict(csrf=csrf,payer_name='Changed',payment_sent=1),files=[('payment_screenshot','proof.png',image,'image/png')])[0]==400,'Approved payment screenshot cannot be replaced')
            check(request('/admin-order.php',dict(csrf=csrf,id=1,status='processing'))[0]==200,'Approved order can be processed')
            check(request('/admin-order.php',dict(csrf=csrf,id=1,status='cancelled'))[0]==200 and connection.execute('SELECT stock FROM products').fetchone()[0]==3,'Cancellation releases reserved stock')
            request('/admin-order.php',dict(csrf=csrf,id=1,status='cancelled'))
            check(connection.execute('SELECT stock FROM products').fetchone()[0]==3,'Repeated cancellation does not duplicate stock')
            check(request('/api/btcpay-webhook.php',{},True)[0]==410,'BTCPay cannot change manual payment status')
            live=json.loads(request('/api/products.php')[1])['products']
            check(live[0]['stock']==3 and live[0]['sats']==12500,'Live stock and BTC quote endpoint')
            check(request('/api/products.php',{})[0]==405,'Product endpoint rejects writes')
            check(request('/admin-product.php',dict(product,id=product_id,remove_image=1))[0]==200 and 'image-placeholder' in request('/')[1],'Product image can be removed')
            check(request('/admin-product.php',dict(product,id=product_id,price='0.00000001',currency='BTC'))[0]==200 and json.loads(request('/api/products.php')[1])['products'][0]['sats']==1,'One-satoshi BTC price supported')
            check(request('/admin-product.php',dict(product,id=product_id,price='0.000000001',currency='BTC'))[0]==400,'Sub-satoshi price rejected')
            connection.execute("INSERT INTO products(name,price_inr,stock,active) VALUES('Legacy',100,1,1)");connection.commit()
            check('Legacy' not in request('/')[1] and 'Needs repricing' in request('/admin.php')[1],'Legacy INR values are not silently relabelled as USD')
            check(request('/admin-product.php',dict(csrf=csrf,id=product_id,delete=1))[0]==200,'Delete product')
            check(request('/admin-logout.php',dict(csrf=csrf))[0]==200 and 'Admin access' in request('/admin.php')[1],'Logout removes admin access')
            connection.close()
            print(f'{checks} checks passed; real storage was not modified.')
        finally:
            server.terminate()
            server.wait(timeout=5)
