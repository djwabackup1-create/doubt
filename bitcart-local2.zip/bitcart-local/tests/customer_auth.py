"""Isolated customer authentication and account ownership tests."""
from contextlib import closing
import http.cookiejar
import json
import os
from pathlib import Path
import re
import socket
import sqlite3
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
checks=0
def check(value,label):
    global checks
    assert value,label
    checks+=1;print('PASS',label,flush=True)
def client():
    jar=http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(jar)),jar
def token(html):return re.search(r'name="csrf" value="([^"]+)"',html)[1]
def sid(jar):return next(cookie.value for cookie in jar if cookie.name=='PHPSESSID')

with tempfile.TemporaryDirectory(prefix='bitcart-auth-') as storage,tempfile.TemporaryFile() as log:
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    env=dict(os.environ,BITCART_STORAGE_DIR=storage)
    def start():return subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(ROOT/'public')],cwd=ROOT,env=env,stdout=log,stderr=log)
    server=start()
    def request(browser,path,data=None,as_json=False):
        headers={}
        if data is not None:
            data=json.dumps(data).encode() if as_json else urllib.parse.urlencode(data).encode()
            if as_json:headers['Content-Type']='application/json'
        try:response=browser.open(urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=data,headers=headers),timeout=10)
        except urllib.error.HTTPError as error:response=error
        return response.status,response.read().decode(),response.geturl()
    def ready():
        for _ in range(100):
            try:
                if request(client()[0],'/')[0]==200:return
            except urllib.error.URLError:pass
            time.sleep(.05)
        raise AssertionError('Test PHP server did not start')
    try:
        ready();alice,alice_jar=client();password='Customer-secret-123!'
        check('/login.php' in request(alice,'/')[2] and 'Continue as a guest' not in request(alice,'/')[1],'Shop requires login and removes guest option')
        check('/login.php' in request(alice,'/account.php')[2],'Account page requires authentication')
        page=request(alice,'/signup.php')[1];csrf=token(page);original_sid=sid(alice_jar)
        check('name="email"' not in page and 'name="contact"' not in page,'Signup collects only chosen credentials')
        data=dict(csrf=csrf,username='Chosen_Name',password=password,confirm=password)
        check(request(alice,'/signup.php',dict(data,csrf='bad'))[0]==419,'Signup CSRF protection')
        check(request(alice,'/signup.php',dict(data,password='short',confirm='short'))[0]==400,'Weak signup password rejected')
        check(request(alice,'/signup.php',dict(data,confirm='does-not-match'))[0]==400,'Password confirmation enforced')
        check(request(alice,'/signup.php',dict(data,username="bad'<script>"))[0]==400,'Invalid username rejected')
        status,page,url=request(alice,'/signup.php',data)
        check(status==200 and url.endswith('/') and 'My account' in page,'Signup immediately authenticates without verification')
        check(sid(alice_jar)!=original_sid,'Signup rotates session ID')
        check(token(page)!=csrf,'Signup rotates CSRF token')
        with closing(sqlite3.connect(Path(storage)/'store.sqlite')) as connection:
            user_id,stored_hash=connection.execute('SELECT id,password_hash FROM customers').fetchone()
            check(stored_hash!=password and stored_hash.startswith('$2'),'Only a password hash is stored')
            connection.execute("INSERT INTO products(name,price_inr,price_currency,stock,active) VALUES('Account product',10,'USD',10,1)")
            connection.executemany('INSERT INTO settings(key,value) VALUES(?,?)',[('bitcoin_address','1BoatSLRHtKNngkdXEeobR76b53LETtpyT'),('usd_per_btc','100000')]);connection.commit()
        duplicate,_=client();dup_csrf=token(request(duplicate,'/signup.php')[1])
        check(request(duplicate,'/signup.php',dict(data,csrf=dup_csrf,username='chosen_name'))[0]==400,'Case-insensitive duplicate username rejected')
        check('/admin-login.php' in request(alice,'/admin.php')[2],'Customer account does not grant admin access')
        check(request(alice,'/admin-product.php',dict(csrf=token(page),name='Unauthorized'))[0]==401,'Customer cannot modify products')
        checkout=request(alice,'/checkout.php')[1]
        check('value="Chosen_Name"' in checkout,'Checkout prefills chosen username')
        order=dict(csrf=token(checkout),name='Paying Alias',contact='@my-contact',items=[dict(id=1,qty=1)],expected_total=.0001,customer_id=9999)
        status,body,_=request(alice,'/api/create-order.php',order,True);result=json.loads(body)
        check(status==200 and result['ok'],'Signed-in checkout succeeds')
        with closing(sqlite3.connect(Path(storage)/'store.sqlite')) as connection:
            check(connection.execute('SELECT customer_id FROM orders').fetchone()[0]==user_id,'Order ownership comes from session, ignoring supplied customer ID')
        page=request(alice,'/account.php')[1]
        check('order=1' in page and '0.00010000 BTC' in page,'Account shows own order and private payment link')
        bob,bob_jar=client();bob_csrf=token(request(bob,'/signup.php')[1])
        check(request(bob,'/signup.php',dict(csrf=bob_csrf,username='Another_User',password=password,confirm=password))[0]==200,'Second independent account created')
        check('order=1' not in request(bob,'/account.php?customer_id='+str(user_id))[1],'Another account cannot retrieve the first account order history')
        guest,_=client();guest_checkout=request(guest,'/checkout.php')
        check('/login.php?next=checkout' in guest_checkout[2],'Checkout requires login and preserves destination')
        check(request(guest,'/api/create-order.php',order,True)[0]==401,'Anonymous direct order creation blocked')
        check(request(guest,'/api/products.php')[0]==401,'Anonymous catalog API blocked')
        check('/login.php' in request(guest,result['url'])[2],'Anonymous payment page requires login')
        status_url=result['url'].replace('/payment.php','/api/order-status.php')
        check(request(guest,status_url)[0]==401,'Anonymous order status blocked')
        check(request(bob,result['url'])[0]==404 and request(bob,status_url)[0]==404,'Other customers cannot view payment or status even with private link')
        check(request(alice,result['url'])[0]==200 and request(alice,status_url)[0]==200,'Order owner can access payment and status')
        check(request(guest,'/media.php?image=missing')[0]==401,'Anonymous product media blocked')
        with closing(sqlite3.connect(Path(storage)/'store.sqlite')) as connection:
            check(connection.execute('SELECT COUNT(*) FROM orders').fetchone()[0]==1,'Blocked guest checkout creates no order')
        csrf=token(request(alice,'/account.php')[1])
        check(request(alice,'/logout.php')[0]==405,'Sign out requires POST')
        check(request(alice,'/logout.php',dict(csrf='bad'))[0]==419,'Sign out requires valid CSRF token')
        before=sid(alice_jar);request(alice,'/logout.php',dict(csrf=csrf))
        check(sid(alice_jar)!=before and '/login.php' in request(alice,'/account.php')[2],'Sign out rotates session and revokes account access')
        login=token(request(alice,'/login.php')[1])
        check(request(alice,'/login.php',dict(csrf='bad',username='Chosen_Name',password=password))[0]==419,'Sign-in CSRF protection')
        check('Incorrect username or password.' in request(alice,'/login.php',dict(csrf=login,username='Chosen_Name',password='wrong'))[1],'Wrong password rejected')
        check('Incorrect username or password.' in request(alice,'/login.php',dict(csrf=login,username='Nobody_Exists',password=password))[1],'Unknown username receives same generic error')
        before=sid(alice_jar)
        status,page,url=request(alice,'/login.php',dict(csrf=login,username='cHoSeN_nAmE',password=password,next='checkout'))
        check(status==200 and url.endswith('/checkout.php'),'Sign-in is case-insensitive and returns to checkout')
        check(sid(alice_jar)!=before,'Sign-in rotates session ID')
        slow,_=client();slow_csrf=token(request(slow,'/login.php')[1])
        for _ in range(8):request(slow,'/login.php',dict(csrf=slow_csrf,username='Chosen_Name',password='wrong'))
        check(request(slow,'/login.php',dict(csrf=slow_csrf,username='Chosen_Name',password=password))[0]==429,'Repeated password guessing is throttled')
        bob_csrf=token(request(bob,'/account.php')[1]);request(bob,'/logout.php',dict(csrf=bob_csrf))
        bob_csrf=token(request(bob,'/login.php')[1])
        check(request(bob,'/login.php',dict(csrf=bob_csrf,username='Another_User',password=password))[2].endswith('/'),'One throttled username does not lock out other onion users')
        with closing(sqlite3.connect(Path(storage)/'store.sqlite')) as connection:
            connection.execute('DELETE FROM customer_auth_attempts');connection.commit()
        server.terminate();server.wait(timeout=5);server=start();ready()
        returning,_=client();csrf=token(request(returning,'/login.php')[1])
        status,page,url=request(returning,'/login.php',dict(csrf=csrf,username='Chosen_Name',password=password,next='https://evil.example'))
        check(status==200 and url.endswith('/') and 'order=1' in request(returning,'/account.php')[1],'Credentials and owned orders survive server restart; external redirects rejected')
        print(f'{checks} customer authentication checks passed; real storage was untouched.',flush=True)
    finally:
        server.terminate();server.wait(timeout=5)
