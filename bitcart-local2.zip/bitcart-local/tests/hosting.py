"""Dependency-free hosting configuration and Tor controller regression tests."""
import base64
from contextlib import closing
import importlib.util
from pathlib import Path, PurePosixPath
import socket
import shutil
import subprocess
import sqlite3
import tempfile
import threading
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]


def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/f'{name}.py')
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


host=module('host_onion')
tor=module('tor_service')
KEY='ED25519-V3:'+base64.b64encode(bytes(range(64))).decode()
SERVICE='a'*56


class FakeTor:
    def __init__(self, cookie=None,tcp=False):
        if tcp:
            with socket.socket() as listener:
                listener.bind(('127.0.0.1',0));listener.listen(1)
                self.controller=tor.Controller(listener.getsockname())
                self.server,_=listener.accept()
        else:
            client,self.server=socket.socketpair()
            self.controller=tor.Controller.__new__(tor.Controller)
            self.controller.socket=client
            self.controller.reader=client.makefile('rb')
        self.commands=[]
        self.cookie=cookie
        self.closed=False
        self.worker=threading.Thread(target=self.run,daemon=True)
        self.worker.start()

    def run(self):
        reader=self.server.makefile('rb')
        try:
            for raw in reader:
                command=raw.decode().strip()
                self.commands.append(command)
                if command=='PROTOCOLINFO 1':
                    path=str(self.cookie).replace('\\','\\\\')
                    reply=f'250-PROTOCOLINFO 1\r\n250-AUTH METHODS=COOKIE,SAFECOOKIE COOKIEFILE="{path}"\r\n250 OK\r\n'
                elif command.startswith('ADD_ONION'):
                    reply='250-ServiceID='+SERVICE+'\r\n'
                    if 'NEW:ED25519-V3' in command:
                        reply+='250-PrivateKey='+KEY+'\r\n'
                    reply+='250 OK\r\n'
                elif command.startswith('AUTHENTICATE'):
                    reply='250 OK\r\n'
                else:
                    reply='552 Unknown command\r\n'
                self.server.sendall(reply.encode())
        finally:
            reader.close()
            self.server.close()
            self.closed=True

    def close(self):
        self.controller.close()
        self.worker.join(timeout=2)


class HostingTests(unittest.TestCase):
    def test_recovery_is_bounded_and_backs_off(self):
        now=[0]
        budget=host.RestartBudget(clock=lambda:now[0])
        self.assertEqual([budget.next_delay() for _ in range(5)],[2,4,8,16,30])
        with self.assertRaises(RuntimeError):budget.next_delay()
        now[0]=601
        self.assertEqual(budget.next_delay(),2)

    def test_backups_are_valid_bounded_and_do_not_change_data(self):
        with tempfile.TemporaryDirectory() as folder:
            storage=Path(folder)
            with closing(sqlite3.connect(storage/'store.sqlite')) as connection:
                connection.execute('CREATE TABLE sample(value TEXT)');connection.execute("INSERT INTO sample VALUES('keep me')");connection.commit()
            for _ in range(5):host.check_persistent_state(storage,backup=True)
            backups=list((storage/'backups').glob('pre-start-*.sqlite'))
            self.assertEqual(len(backups),3)
            for database in backups:
                with closing(sqlite3.connect(database)) as connection:self.assertEqual(connection.execute('SELECT * FROM sample').fetchall(),[('keep me',)])

    def test_corruption_stops_without_resetting_database(self):
        with tempfile.TemporaryDirectory() as folder:
            storage=Path(folder);database=storage/'store.sqlite';database.write_bytes(b'damaged database')
            with self.assertRaises(RuntimeError):host.check_persistent_state(storage,backup=True)
            self.assertEqual(database.read_bytes(),b'damaged database')
            self.assertFalse((storage/'backups').exists())

    def test_recovery_never_replaces_lost_or_damaged_identity(self):
        with tempfile.TemporaryDirectory() as folder:
            storage=Path(folder);identity=storage/'onion';identity.mkdir();(identity/'hostname').write_text(SERVICE+'.onion')
            with self.assertRaises(RuntimeError):host.check_persistent_state(storage)
            self.assertFalse((identity/'private_key').exists())
            (identity/'private_key').write_text('broken')
            with self.assertRaises(RuntimeError):host.check_persistent_state(storage)
            self.assertEqual((identity/'private_key').read_text(),'broken')

    def test_shortcuts_use_real_desktop_and_keep_storage_settings(self):
        with tempfile.TemporaryDirectory() as folder:
            home=Path(folder);project=home/'Store Files';project.mkdir();storage=home/'Private Data'
            with patch.object(host.shutil,'which',return_value=None):host.create_desktop_launcher(project,storage,8099,home)
            for directory in (project,home/'Desktop',home/'.local/share/applications'):
                text=(directory/'Start BitCart.desktop').read_text()
                self.assertIn('BITCART_PORT=8099',text);self.assertIn(host.desktop_argument('BITCART_STORAGE_DIR='+str(storage)),text)
                self.assertIn('/bin/sh',text);self.assertIn('Terminal=true',text)
                self.assertIn('--stop',(directory/'Stop BitCart.desktop').read_text())

    def test_invalid_status_data_cannot_target_processes(self):
        self.assertFalse(host.status_alive({}))
        self.assertFalse(host.status_alive({'pid':1,'token':'pretend'}))
        self.assertFalse(host.status_alive({'pid':'invalid','token':'pretend'}))

    @unittest.skipUnless(shutil.which('php'),'PHP CLI not installed')
    def test_first_admin_password_is_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            password='Temporary-strong-password-123!'
            with patch('sys.stdin.isatty',return_value=True),patch.object(host.getpass,'getpass',return_value=password):
                host.ensure_admin(shutil.which('php'),Path(folder))
            result=subprocess.check_output([shutil.which('php'),'-r','$c=require $argv[1];echo password_verify(stream_get_contents(STDIN),$c["password_hash"])?"OK":"FAIL";',str(Path(folder)/'config.php')],input=password,text=True)
            self.assertEqual(result,'OK')
            # A repeat launch validates the existing config without replacing it.
            previous=(Path(folder)/'config.php').read_bytes()
            host.ensure_admin(shutil.which('php'),Path(folder))
            self.assertEqual((Path(folder)/'config.php').read_bytes(),previous)

    def test_localhost_only_nginx(self):
        config=host.nginx_config(PurePosixPath('/home/test/Store Files'),PurePosixPath('/tmp/bitcart-test'),8080)
        self.assertIn('listen 127.0.0.1:8080;',config)
        self.assertNotIn('0.0.0.0',config)
        self.assertIn('root "/home/test/Store Files/public";',config)
        self.assertIn('location = /setup.php { return 404; }',config)
        self.assertIn('access_log off;',config)
        self.assertIn('try_files $uri =404;',config)

    def test_private_php_settings(self):
        config=host.fpm_config(PurePosixPath('/home/test/Persistent/private'),PurePosixPath('/tmp/bitcart-test'),'amnesia','amnesia')
        self.assertIn('env[BITCART_STORAGE_DIR] = "/home/test/Persistent/private"',config)
        self.assertIn('listen.mode = 0600',config)
        self.assertIn('session.use_strict_mode',config)
        self.assertIn('upload_max_filesize] = 10M',config)
        self.assertIn('display_errors] = off',config)

    def test_config_injection_rejected(self):
        with self.assertRaises(RuntimeError): host.quoted('/tmp/a\nlisten 0.0.0.0')
        with self.assertRaises(RuntimeError): host.ini_quoted('/tmp/${SECRET}')
        with self.assertRaises(RuntimeError): host.fpm_config(Path('/tmp'),Path('/tmp'),'bad\nuser','group')

    def test_private_storage_not_public(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            with self.assertRaises(RuntimeError): host.storage_location(root,str(root/'public/uploads'),False,root)

    def test_tails_requires_persistence(self):
        with tempfile.TemporaryDirectory() as temp:
            home=Path(temp)
            with self.assertRaises(RuntimeError): host.storage_location(home/'Downloads/store',None,True,home)
            (home/'Persistent').mkdir()
            with self.assertRaises(RuntimeError): host.storage_location(home/'Downloads/store',None,True,home)
            project=home/'Persistent/store'
            self.assertEqual(host.storage_location(project,None,True,home),(project/'storage').resolve())

    def test_cookie_authentication(self):
        with tempfile.TemporaryDirectory() as temp:
            cookie=Path(temp)/'control.authcookie';cookie.write_bytes(b'x'*32)
            fake=FakeTor(cookie)
            try:
                fake.controller.authenticate()
                self.assertEqual(fake.commands[-1],'AUTHENTICATE '+(b'x'*32).hex())
            finally: fake.close()

    def test_new_key_persisted_and_reused(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)/'onion'
            fake=FakeTor()
            try:
                self.assertEqual(tor.register(fake.controller,directory,8080),SERVICE+'.onion')
                self.assertEqual((directory/'private_key').read_text().strip(),KEY)
                self.assertEqual((directory/'hostname').read_text().strip(),SERVICE+'.onion')
                self.assertIn('Port=80,127.0.0.1:8080',fake.commands[0])
                self.assertNotIn('Detach',fake.commands[0])
                tor.register(fake.controller,directory,8081)
                self.assertTrue(fake.commands[-1].startswith('ADD_ONION '+KEY+' '))
                self.assertIn('127.0.0.1:8081',fake.commands[-1])
            finally: fake.close()
            self.assertTrue(fake.closed)

    def test_missing_key_does_not_change_address(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            (directory/'hostname').write_text(SERVICE+'.onion\n')
            fake=FakeTor()
            try:
                with self.assertRaises(tor.ControlError): tor.register(fake.controller,directory,8080)
                self.assertEqual(fake.commands,[])
            finally: fake.close()

    def test_invalid_saved_key_is_not_replaced(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            (directory/'private_key').write_text('broken key')
            fake=FakeTor()
            try:
                with self.assertRaises(tor.ControlError): tor.register(fake.controller,directory,8080)
                self.assertEqual((directory/'private_key').read_text(),'broken key')
            finally: fake.close()

    def test_controller_rejects_newline_and_error(self):
        fake=FakeTor()
        try:
            with self.assertRaises(tor.ControlError): fake.controller.command('GETINFO a\r\nSIGNAL HALT')
            with self.assertRaises(tor.ControlError): fake.controller.command('UNKNOWN')
        finally: fake.close()

    def test_control_tcp_endpoint_cannot_be_remote(self):
        with self.assertRaises(tor.ControlError):tor.Controller(('192.0.2.1',9052))

    def test_loopback_tcp_cookie_authentication(self):
        with tempfile.TemporaryDirectory() as folder:
            cookie=Path(folder)/'cookie';cookie.write_bytes(b'x'*32)
            fake=FakeTor(cookie,tcp=True)
            try:
                fake.controller.authenticate()
                self.assertEqual(fake.commands[-1],'AUTHENTICATE '+(b'x'*32).hex())
            finally:fake.close()


if __name__=='__main__': unittest.main(verbosity=2)
